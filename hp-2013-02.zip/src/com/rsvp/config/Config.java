package com.rsvp.config;

public class Config {
	/**
	 * Database Configuration
	 */
	public static final String DRIVER		= Configurations.getStringProperty("db.driver", "oracle.jdbc.driver.OracleDriver");
	public static final String URL			= Configurations.getStringProperty("db.url", "jdbc:oracle:thin:@localhost:1521:ORCL");
	public static final String DBUSER		= Configurations.getStringProperty("db.user", "Database User Name");
	public static final String DBPASS		= Configurations.getStringProperty("db.pass", "Database password");
	public static final int MAX_POOL		= Configurations.getIntProperty("db.poolmaxsize", 10);
	public static final int MIN_POOL   		= Configurations.getIntProperty("db.poolminsize", 5);
	public static final int WIAT			= Configurations.getIntProperty("db.maxwaitmillis", 3000);
	public static final String HOST			= Configurations.getStringProperty("db.host", "localhost");
	public static final int PORT			= Configurations.getIntProperty("db.port", 1521);
	public static final String DB_LINK_NAME	= Configurations.getStringProperty("db.linkname", "");
	public static final String DB_NAME		= Configurations.getStringProperty("db.name", "");
	
	
	/***
	 * Table Configuration
	 */
	public static final String TB_PREFIX				= Configurations.getStringProperty("tb.prefix", "PJT2_");
	public static final String MASTER_TB_KISS			= Configurations.getStringProperty("tb.master.kiss", "SR_KISS_1206");
	public static final String MASTER_TB_USER			= Configurations.getStringProperty("tb.master.user", "UA_USERACCOUNT_1206");
	public static final String MASTER_TB_PICTURE		= Configurations.getStringProperty("tb.master.picture", "UP_PICTURE");
	public static final String MASTER_TB_LOCUSPOINT		= Configurations.getStringProperty("tb.master.locus", "UL_LOCUSPOINTS");
	public static final String MASTER_TB_PROPERTY		= Configurations.getStringProperty("tb.master.property", "UP_PROPERTY");
	public static final String MASTER_TB_PREPLIES		= "PR_POSITIVE_REPLIES";
	
	
	/** Train tables **/
	public static final String TB_TRDATASET				= TB_PREFIX+"TR_DATASET";
	public static final String TB_TRPROPERTY			= TB_PREFIX+"TR_PROPERTY";
	public static final String TB_TRKISS_LOG			= TB_PREFIX+"TR_KISSLOG";
	public static final String TB_TRUSER				= TB_PREFIX+"TR_USER";
	
	public static final String TB_TRLHS2RHS				= TB_PREFIX+"TR_LHS2RHS";
	public static final String TB_TRSUBGROUP_USER		= TB_PREFIX+"TR_SUBGROUP_USER";
	public static final String TB_TRMETRIC				= TB_PREFIX+"TR_METRIC";
	
	public static final String TB_TRLHS2Q				= TB_PREFIX+"TR_LHS2Q";
	public static final String TB_TRP2RHS				= TB_PREFIX+"TR_P2RHS";
	public static final String TB_TRP2Q					= TB_PREFIX+"TR_P2Q";
	public static final String TB_TRKISSSUMMARY			= TB_PREFIX+"TR_INTSUMMARY";
	public static final String TB_TRLOOKUP				= TB_PREFIX+"TR_LOOKUP";
	public static final String TB_TRSUBGROUP_INTEREST	= TB_PREFIX+"TR_LOOKUP_EXT";
	public static final String TB_TRTHRESHOLD			= TB_PREFIX+"TR_THRESHOLD";
	public static final String TB_TRSIMSUBGROUP			= TB_PREFIX+"TR_SIM_SUBGROUP";
	
	public static final String TB_TRIMSSIMSUBGROUP		= TB_PREFIX+"TR_SIM_IMSSUBGROUP";
	public static final String TB_TRPIMSSIMSUBGROUP		= TB_PREFIX+"TR_SIM_PIMSSUBGROUP";
	public static final String TB_TRLMSSIMSUBGROUP		= TB_PREFIX+"TR_SIM_LMSSUBGROUP";
	public static final String TB_TRPLMSSIMSUBGROUP		= TB_PREFIX+"TR_SIM_PLMSSUBGROUP";
	
	public static final String TB_TRBESTMATCH			= TB_PREFIX+"TR_BESTMATCHATT";
	
	
	public static final String TB_TRSCORETHRESHOLD		= TB_PREFIX+"TR_SCORE_THRESHOLD";
	
	public static final String TB_TRIMSTHRESHOLD		= TB_PREFIX+"TR_IMS_THRESHOLD";
	public static final String TB_TRPIMSTHRESHOLD		= TB_PREFIX+"TR_PIMS_THRESHOLD";
	public static final String TB_TRLMSTHRESHOLD		= TB_PREFIX+"TR_LMS_THRESHOLD";
	public static final String TB_TRPLMSTHRESHOLD		= TB_PREFIX+"TR_PLMS_THRESHOLD";
	
	
	
	public static final String TB_TRSUCESS_RATE			= TB_PREFIX+"TR_SUCCESS_RATE";
	public static final String TB_TRKISSUSER			= TB_PREFIX+"TR_KISS_USER";
	
	public static final String TB_TRSUBSETKISSES		= TB_PREFIX+"TR_SUBKISSES";
	
	
	
	
	/** Rule tables **/
	public static final String TB_LNDATASET				= TB_PREFIX+"LN_DATASET";
	public static final String TB_LNRULE				= TB_PREFIX+"LN_RULEBASE";
	public static final String TB_LNFAILED_RULE			= TB_PREFIX+"LN_RULEBASE_FAILED";
	public static final String TB_RCUSERCUSER_TMP		= TB_PREFIX+"RC_USER_CUSERS_TMP";
	
	
	public static final int ROOT_RULE_ID				= 0;
	public static final int DEFAULT_RULE_ID				= -1;
	public static final int DEFAULT_USER_ID				= 0;
	public static final int NULL_VALUE 					= 1000000;
	public static final int NOT_IMPORTANT				= 0;
	public static final int INTERVAL_DAYS				= 28;
	public static final float CONFIDENCE 				= (float) 0.95;

	public static final boolean SQL_LOG					= Configurations.getBooleanProperty("log.sql", true);
	public static final boolean INFO_LOG				= Configurations.getBooleanProperty("log.info", false);
	public static final boolean ERROR_LOG				= Configurations.getBooleanProperty("log.error", false);
}
