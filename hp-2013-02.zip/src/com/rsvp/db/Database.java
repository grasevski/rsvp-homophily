package com.rsvp.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.rsvp.log.LoggerWrapper;

public class Database {
	private Connection m_Connection;
	
	public Database(Connection conn) {
		this.setDb(conn);
	}
	
	/**
	 * Truncate table space
	 * @param tableName
	 * @throws SQLException
	 */
	public void truncateTable(String tableName) {
		String sql = "TRUNCATE TABLE "+tableName;
		PreparedStatement ps = null;
		ResultSet rs = null;	
		try {
			ps = this.m_Connection.prepareStatement(sql);
			rs = ps.executeQuery();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}finally {
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}			
		}		
	}

	public void insertQuery(String sql) throws SQLException{
		PreparedStatement ps = null;
		try {
			this.m_Connection.setAutoCommit(true);
			ps = this.m_Connection.prepareStatement(sql);
			ps.execute(); 
		} catch (SQLException e) {
			System.out.print(sql);
			e.printStackTrace();
		}finally {
			if(ps!=null)
				ps.close();
		}		
	}
	
	
	
	public void updateQuery(String sql) {
		PreparedStatement ps = null;
		try {
			this.m_Connection.setAutoCommit(true);
			ps = this.m_Connection.prepareStatement(sql);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}		
	}
	
	public ResultSet selectQuery(String sql) throws SQLException {
		PreparedStatement ps = null;
		ResultSet rs = null;	
		try {
			ps = this.m_Connection.prepareStatement(sql);
			rs = ps.executeQuery();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}finally {
			if(ps!=null)
				ps.close();
			if(rs!=null)
				rs.close();			
		}
		return rs;	
	}
	
	/**
	 * Get latest id
	 * @param tableName
	 * @return
	 * @throws SQLException 
	 */
	public int getLastID(String id, String tableName){
		int newid = 0;
		int lastID = 0;
		String sql = "SELECT max("+id+") FROM "+tableName;
		PreparedStatement ps = null;
		ResultSet rs = null;	
		try {
			ps = this.m_Connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while( rs.next() ){
				lastID = rs.getInt(1);
			}
			newid = lastID+1;
				
		} catch (SQLException e) {
			LoggerWrapper.info("train", "getLastID query: " + sql);	
			e.printStackTrace();
		}finally {
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(ps!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}			
		}
		return newid; 		
	}	
	
	public int isDatabaseLinkExist(String databaseLinkName, String dbLinkTable) throws SQLException {
		int linkCount=0;
		int linkNameLenth = databaseLinkName.length();
		String sql = "SELECT SUBSTR(DB_LINK, 0,"+linkNameLenth+") FROM "+dbLinkTable; 
		PreparedStatement ps = null;
		ResultSet rs = null;	
		try {
			ps = this.m_Connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while( rs.next() ){
				if(rs.getString(1).equals(databaseLinkName)){
					linkCount++;
				}
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			if(ps!=null)
				ps.close();
			if(ps!=null)
				rs.close();			
		}	
		return linkCount;
	}
	
	public void dropTable(String tableName) {
		String sql = "DROP TABLE "+tableName +" PURGE";
		PreparedStatement ps = null;
		ResultSet rs = null;	
		try {
			ps = this.m_Connection.prepareStatement(sql);
			rs = ps.executeQuery();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}finally {
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}			
		}		
	}
	
	/**
	 * Check whether table exist or not
	 * @param tableName
	 * @return if exist  return 1 else 0
	 * @throws SQLException
	 */
	public int isTableExist(String tableName) {
		int tableCount = 0 ;
		String sql = "SELECT COUNT(*)AS TB_COUNT FROM USER_TABLES WHERE TABLE_NAME='"+tableName+"'";
		PreparedStatement ps = null;
		ResultSet rs = null;	
		try {
			ps = this.m_Connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while( rs.next() ){
				tableCount = rs.getInt(1);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally {
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(ps!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}			
		}		
		return tableCount;		
	}
	
	public void setDb(Connection db) {
		this.m_Connection = db;
	}
	
	public Connection getDb() {
		return m_Connection;
	}
}
