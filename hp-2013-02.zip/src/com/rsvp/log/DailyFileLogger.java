package com.rsvp.log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

import com.rsvp.log.DailyFileLogger;

/**
 * Logger implementation, which logs message into file system. The log file is created every day and
 * formatted like "[logger name]-yyyy-MM-dd.log".
 * 
 * @since ver 1.0.0
 */
public class DailyFileLogger {
	private static Hashtable<String, DailyFileLogger> fileLogger = new Hashtable<String, DailyFileLogger>();
	private SimpleDateFormat fileFormat = new SimpleDateFormat( "yyyy-MM-dd");
	private String currentDate;
	
	private PrintWriter logWriter = null;
	private boolean nullLogger = false;
	private String logDir;
	
	class WatchDogThread extends Thread{
		public void run(){
			while( true ){
				try {
					sleep( 3 );
				} catch (InterruptedException e) {
				}

				try{
					String logDate = fileFormat.format(new Date());
					if( !logDate.equals(currentDate) ){
						synchronized( fileLogger ){
							Enumeration<String> loggerNames = fileLogger.keys();
							while( loggerNames.hasMoreElements() ){
								String loggerName = loggerNames.nextElement();
								DailyFileLogger dailyLogger = fileLogger.get(loggerName);
								if( !dailyLogger.nullLogger ){
									dailyLogger.closeLogWriter();
									dailyLogger.createLogWriter(loggerName, logDir);
								}
							}
						}
					}
				}catch( Throwable th ){
					th.printStackTrace();
				}
			}
		}
	}
	
	private DailyFileLogger( String loggerName, String logDir ){
		createLogWriter( loggerName, logDir );
//		new WatchDogThread().start();
	}
	
	private void closeLogWriter(){
		logWriter.close();
	}
	
	private void createLogWriter( String loggerName, String logDir ){
		currentDate = fileFormat.format(new Date());
		
		if( loggerName != null ) {
			this.logDir = logDir;
			if( logDir != null ){
				logDir += File.separator;
				String logFile = logDir + File.separator + loggerName + "-" + currentDate + ".log";
				try {
					logWriter = new PrintWriter( new FileWriter(logFile, true));
					return;
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		logWriter = new PrintWriter( System.out );
		nullLogger = true;
	}
	
	/**
	 * Get logger instance
	 * 
	 * @param loggerName, log message into standard out if loggerName is null
	 * @param logDir, directory name which contains log files
	 * @return
	 */
	public static synchronized DailyFileLogger getInstance( String loggerName, String logDir ){
		DailyFileLogger dailyFileLogger = null;
		
		synchronized( fileLogger ){
			dailyFileLogger =  fileLogger.get(loggerName);
			if( dailyFileLogger == null ){
				dailyFileLogger = new DailyFileLogger( loggerName, logDir );
				fileLogger.put( loggerName, dailyFileLogger );
			}
		}
		
		return dailyFileLogger;
	}
	
	public void printStackTrace( Throwable e ){
		e.printStackTrace( logWriter );
		logWriter.flush();
	}

	public void info(String msg) {
		logWriter.println( msg );
		logWriter.flush();
	}
	
	public void debug(String msg) {
		logWriter.println( msg );
		logWriter.flush();
	}

	public void error(String msg) {
		logWriter.println( msg );
		logWriter.flush();
	}

	public void warn(String msg) {
		logWriter.println( msg );
		logWriter.flush();
	}
	
}
