package com.rsvp.log;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
//import java.util.logging.Level;
import com.rsvp.log.DailyFileLogger;

public class LoggerWrapper {
	public static SimpleDateFormat loggerFormat = new SimpleDateFormat( "[yyyy-MM-dd,HH:mm:ss]");
	public static String defaultLoggerName = "rsvp-log";
	public static String HOMEDIR_PROP_KEY = "blogmon.home.dir";
	private static String logDir;
	
	static{
		logDir = System.getProperty( HOMEDIR_PROP_KEY );
		if( logDir != null ){
			logDir += File.separator + "logs";
		}
	}
	
//	private static Logger logger;
//	static{
//		String logDir = System.getProperty( ConfigConstants.HOMEDIR_PROP_KEY );
//		if( logDir != null ){
//			logDir += File.separator + "logs";
//		}
//
//		String logDir = "logs/";
//		try {
//			FileHandler fileHandler = new FileHandler( logDir + File.separator + "rsvp.log", true );
//			fileHandler.setFormatter( new SimpleFormatter() );
//			String loggerName;
//			logger = Logger.getLogger( defaultLoggerName );
//			logger.addHandler( fileHandler );
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//
//		if( logger == null ){
//			logger = Logger.getAnonymousLogger();
//		}
//
//		logger.setLevel( Level.ALL );
//	}
	
	public static String getLoggingTime(){
		return loggerFormat.format( new Date() );
	}

	public static String getCallerInfo(){
		Throwable th = new Throwable();
		StackTraceElement[] ste = th.getStackTrace();
		String className = ste[2].getClassName();
		int idx = className.lastIndexOf('.');
		if( idx > 0 )
			className = className.substring(idx+1);
		return "[" + className + "." + ste[2].getMethodName() + ":" + ste[2].getLineNumber() + "]";
	}

	public static void printStackTrace( String loggerName, Throwable e ){
//		logger.log( Level.SEVERE, e.getMessage(), e );
		DailyFileLogger.getInstance(loggerName, logDir).printStackTrace(e);
	}

	public static void info(String loggerName, String msg) {
//		logger.log( Level.INFO, getLoggingTime() + "[I]" +  getCallerInfo() + msg );
		DailyFileLogger.getInstance(loggerName, logDir).info(getLoggingTime() + "[I]" +  getCallerInfo() + msg);
	}
	
	public static void dbinfo(String loggerName, String msg) {
		DailyFileLogger.getInstance(loggerName, logDir).info(getLoggingTime() + "[I]" +  getCallerInfo() + msg);
	}
	
	
	public static void debug(String loggerName, String msg) {
//		logger.log( Level.OFF, msg );
		DailyFileLogger.getInstance(loggerName, logDir).debug(getLoggingTime() + "[D]" +  getCallerInfo() + msg);
	}

	public static void error(String loggerName, String msg) {
//		logger.log( Level.SEVERE, msg );
		DailyFileLogger.getInstance(loggerName, logDir).error(getLoggingTime() + "[E]" +  getCallerInfo() + msg);
	}

	public static void warn(String loggerName, String msg) {
//		logger.log( Level.WARNING, msg );
		DailyFileLogger.getInstance(loggerName, logDir).warn(getLoggingTime() + "[W]" +  getCallerInfo() + msg);
	}

	public static void errorPrintStackTrace(String loggerName, Throwable e) {
		DailyFileLogger.getInstance(loggerName, logDir).printStackTrace(e);
	}

	public static void debug( String loggerName, Object obj) {
		//logger.log( Level.OFF, obj.toString() );
		DailyFileLogger.getInstance(loggerName, logDir).debug(getLoggingTime() + "[D]" +  getCallerInfo() + obj.toString());
	}
}
