package com.rsvp.rules.core;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;


public class Attribute {
	
	public Attribute() {

	}
	
//	public Attribute(Connection conn) {
//		this.m_Connection   = conn;
//		this.attibuteTable 	= new HashMap<Integer,Map<Integer,String>>();
//	}

	/**
	 * Map for attribute id - name pair
	 * @return
	 */
	public static Map<Integer,String> getAttributeIDNamePair()  
	{
		Map<Integer,String> p = new HashMap<Integer, String>();
		p.put(1, "OCC_INDUSTRY_PRID");
		p.put(2, "OCC_LEVEL_PRID");
		p.put(3, "HAVEPETS");
		p.put(4, "GENDER_PRID");
		p.put(5, "MARITAL_STATUS_PRID");
		p.put(6, "BODYTYPE_PRID");
		p.put(7, "EYECOLOR_PRID");
		p.put(8, "STARSIGN_PRID");
		
		p.put(9, "HAIRCOLOR_PRID");
		p.put(10, "ETHNICBACKGROUND_PRID");
		p.put(12, "HAVECHILDREN_PRID");
		p.put(13, "SMOKE_PRID");
		p.put(14, "RELIGION_PRID");
		p.put(15, "WANTCHILDREN_PRID");
		p.put(16, "EDUCATION_PRID");
		
		p.put(17, "POLITICS_PRID");
		p.put(18, "DIET_PRID");
		p.put(19, "HEIGHT_PRID");
		p.put(20, "PERSONALITY_PRID");
		p.put(22, "DRINK_PRID");
//		p.put(23, "SEXUALITY_PRID");
//		p.put(24, "PLATONIC_GENDER_SOUGHT_PRID");

		p.put(50, "AGE_BIN");
		p.put(51, "LOC_LOCUSPOINTID");
//		p.put(52, "LOC_DIVISIONID");
//		p.put(56, "LOC_COUNTRYID");
//		p.put(57, "LOC_REGIONID");
//		p.put(58, "SEEKINGPENPAL");
//		p.put(59, "SEEKINGFRIEND");		
//		p.put(60, "CHIRDREN_BIN");
//		p.put(61, "PIC_BIN");
//		p.put(62, "SEEKINGRELSHORT");
//		p.put(63, "SEEKINGRELLONG");
//		p.put(64, "HHASPHOTO");
//		p.put(65, "HHASSECONDARYPHOTO");
//		p.put(66, "NATIONALITY_PRID");
		return p;
	}

	
	/**
	 * Map for attribute name - id pair
	 * @return
	 */
	public static Map<String, Integer> getAttributeNameIDPair() 
	{
		Map<String, Integer> p = new HashMap<String, Integer>();
		p.put("OCC_INDUSTRY_PRID", 1);
		p.put("OCC_LEVEL_PRID", 2);
		p.put("HAVEPETS", 3);
		p.put("GENDER_PRID", 4);
		p.put("MARITAL_STATUS_PRID", 5);
		p.put("BODYTYPE_PRID", 6);
		p.put("EYECOLOR_PRID", 7);
		p.put("STARSIGN_PRID", 8);
		
		p.put("HAIRCOLOR_PRID", 9);
		p.put("ETHNICBACKGROUND_PRID", 10);
		p.put("HAVECHILDREN_PRID", 12);
		p.put("SMOKE_PRID", 13);
		p.put("RELIGION_PRID", 14);
		p.put("WANTCHILDREN_PRID", 15);
		p.put("EDUCATION_PRID", 16);
		
		p.put("POLITICS_PRID", 17);
		p.put("DIET_PRID", 18);
		p.put("HEIGHT_PRID", 19);
		p.put("PERSONALITY_PRID", 20);
		p.put("DRINK_PRID", 22);
		p.put("SEXUALITY_PRID", 23);
//		p.put("PLATONIC_GENDER_SOUGHT_PRID", 24);

		p.put("AGE_BIN", 50);
		p.put("LOC_LOCUSPOINTID", 51);
		p.put("LOC_DIVISIONID", 52);
//		p.put("LOC_COUNTRYID", 56);
//		p.put("LOC_REGIONID", 57);
//		p.put("SEEKINGPENPAL", 58);
//		p.put("SEEKINGFRIEND", 59);
//
//		p.put("CHIRDREN_BIN", 60);
//		p.put("PIC_BIN", 61);
//		p.put("SEEKINGRELSHORT", 62);
//		p.put("SEEKINGRELLONG", 63);
		
//		p.put("HHASPHOTO", 64);
//		p.put("HHASSECONDARYPHOTO", 65);
//		p.put("NATIONALITY_PRID", 66);
		return p;
	}

	public static int getAttributeID(String attributeName) {
		int attID = 0;
		Map<String, Integer> attributes = Attribute.getAttributeNameIDPair();
		Set<Entry<String, Integer>> s = attributes.entrySet();
	    Iterator<Entry<String, Integer>>  it=s.iterator();
	    while(it.hasNext()) {
	    	Entry<String, Integer> entry = it.next();
	    	String attName =(String)entry.getKey();
	        if(attName.equals(attributeName)) {
	        	attID = (Integer)entry.getValue();
	        	break;
	        }
	    }
	    //	LoggerWrapper.info("attribute", "Query: " +attributeName+ "'s ID :" + attID);		
	    return attID;
	}	
	
	
	
	
	/**
	 * Get attribute name from train user table and get attribute id
	 * @return
	 * @throws SQLException
	 */
//	public Map<Integer,String> getAttributeIDName() throws SQLException
//	{
//		Map<Integer,String> p = new HashMap<Integer, String>();
//		String sql = "SELECT column_name FROM user_tab_columns WHERE table_name = '"+Config.TB_TRUSER+"'";
//		LoggerWrapper.info("attribute", "Query: " + sql);
//		System.exit(0);
//		PreparedStatement ps = null;
//		ResultSet rs = null;	
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				int propertyTypeID = getAttributeID(rs.getString(1));
//				LoggerWrapper.info("attribute", "Property Type: " + propertyTypeID);
//				if(propertyTypeID>0){
//					LoggerWrapper.info("attribute", "Property Type: " + rs.getString(1));
//					p.put(propertyTypeID, rs.getString(1));
//				}
//			}
//		} catch (SQLException e1) {
//			e1.printStackTrace();
//		}finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();			
//		}
//		return p;
//	}
	

	
	/**
	 * Get property type id from 
	 * @param attributeName
	 * @return
	 * @throws SQLException
	 */
//	public int getAttributeID(String attributeName) throws SQLException{
//		int id = 0;
//		String sql = "SELECT PROPTYPEID FROM "+ tbconfig.getTbAttributeType()+" WHERE TYPETOFIELD='"+attributeName+"'";
////		LoggerWrapper.info("attribute", "Query: " + sql);
////		System.exit(0);
//		PreparedStatement ps = null;
//		ResultSet rs = null;	
//		try {
//			ps = db.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
////				LoggerWrapper.info("attribute", "ID: " + sql);
//				id = rs.getInt(1);
//			}
//		} catch (SQLException e1) {
//			e1.printStackTrace();
//		}finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();			
//		}		
//		return id;
//	}
	
//	public Vector<Integer> getDistinctAttributeValues(String attributeName, int trainDataSetID) throws SQLException {
//		Vector<Integer> attValues= new Vector<Integer>();
//		
//		String sql = "SELECT DISTINCT("+attributeName+") FROM "+ Config.TB_TRUSER +" " +
//				"WHERE TRAINDATASET_ID="+trainDataSetID+" ORDER BY "+attributeName+" ASC";
//		//LoggerWrapper.info("attribute", "Query: " + sql);
//		PreparedStatement ps = null;
//		ResultSet rs = null;	
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				attValues.add(rs.getInt(1));
//			}
//		} catch (SQLException e1) {
//			e1.printStackTrace();
//		}finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();			
//		}		
//		return attValues;	
//	}
	
//	public static Vector<Integer> getDistinctAttributeValues(Connection conn, String attributeName) throws SQLException {
//		Vector<Integer> attValues= new Vector<Integer>();
//		
//		String sql = "SELECT DISTINCT("+attributeName+") FROM "+ Config.TB_TRUSER +"  ORDER BY "+attributeName+" ASC";
//		LoggerWrapper.info("attribute", "Query: " + sql);
//		PreparedStatement ps = null;
//		ResultSet rs = null;	
//		try {
//			ps = conn.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				attValues.add(rs.getInt(1));
//			}
//		} catch (SQLException e1) {
//			e1.printStackTrace();
//		}finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();			
//		}		
//		return attValues;	
//	}
	
//	public void toString(Map<Integer,String> attributeIDName) {
//		Set<Entry<Integer, String>> attElememnt = attributeIDName.entrySet();
//		Iterator<Map.Entry<Integer, String>> attIterator = attElememnt.iterator();
//		while (attIterator.hasNext()) {
//		    Map.Entry<Integer, String> anEntry = attIterator.next();
//		    Integer attID = (Integer)anEntry.getKey();
//		    String attValue =  (String)anEntry.getValue();
//			LoggerWrapper.info("train", "Profile " + attID+ ":"+attValue);
//		}		
//	}
	
	/**
	 * Load property table into map
	 * @throws SQLException 
	 */
//	public void loadAttributeTable() throws SQLException {
//		Map<Integer,String> property = getAttributeIDNamePair();
//		
//		Set<Map.Entry<Integer, String>> propertyIdNames = property.entrySet();
//		Iterator<Map.Entry<Integer, String>> propertyIterator = propertyIdNames.iterator();
//		while (propertyIterator.hasNext())
//		{
//			Map.Entry<Integer, String> anEntry = propertyIterator.next();
//			Integer typeID = (Integer)anEntry.getKey();
//			Map<Integer,String> attIdValueName =  getAttributeIdValueNamePair(typeID); 
//			this.attibuteTable.put(typeID, attIdValueName);
//		}
//		LoggerWrapper.info("train", "End loading attribute table... " );	
//	}
	
//	public Map<Integer,String> getAttributeIdValueNamePair(int typeID) throws SQLException {
//		Map<Integer,String> attIdValueName = new HashMap<Integer,String>();
//		String sql = "SELECT pt.VALUEID, pt.VALUENAME FROM "+ Config.TB_TRPROPERTY+ " pt WHERE pt.PROPERTYID="+typeID;
//	
//		PreparedStatement ps = null;
//		ResultSet rs = null;	
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				int propertyTypeID = rs.getInt(1);
//				String propertyTypeName = rs.getString(2);
////				LoggerWrapper.info("attribute", "Property Type: " + propertyTypeID);
//				if(propertyTypeID>0){
////					LoggerWrapper.info("attribute", "Property Type: " + rs.getString(1));
//					attIdValueName.put(propertyTypeID, propertyTypeName);
//				}
//			}
//		} catch (SQLException e1) {
//			e1.printStackTrace();
//		}finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();			
//		}
//		return attIdValueName;		
//	}
	
	/**
	 * Get attribute name by give attribute id and attribute value id
	 * @param attID
	 * @param attValueId
	 * @return
	 */
//	public String getAttributeNameByID(int attID, int attValueId) {
//		String attName = "";
//		if(this.attibuteTable!=null) {
//			attName = this.attibuteTable.get(attID).get(attValueId);
//		} else {
//			
//		}
//		return attName;
//	}
	
	
//	public void unloadAttbibuteTable() {
//		this.attibuteTable = null;
//	}
	
	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		Attribute m_Manager = new Attribute();
//		String attributeName = "SEEKINGPENPAL"; 
//		m_Manager.getAttributeID(attributeName);
//		XStream xstream = new XStream();
//		ConfigDatabase m_ConfigDatabase = new  ConfigDatabase();
//		String configDir = "C:/Users/yangsokk/Documents/My Java/RSVPRuleRec/bin/com/rsvp/config/";
//		String strDBConfig = m_ConfigDatabase.readConfig(configDir+"eval_db_rsvp.xml");
//		ConfigDatabase dbconfig = (ConfigDatabase)xstream.fromXML(strDBConfig);		
//
//		ConfigTable	m_ConfigTable = new ConfigTable();
//		String strTBConfig = m_ConfigTable.readConfig(configDir+"eval_table.xml");
//		ConfigTable tbconfig = (ConfigTable)xstream.fromXML(strTBConfig);
//
//		
//		ConnPoolProperty prop = new ConnPoolProperty();
//		prop.setUrl(dbconfig.getDbURI());
//		prop.setDriverClass(dbconfig.getDbDriverName());
//		prop.setUser(dbconfig.getDbUser());
//		prop.setPassword(dbconfig.getDbPassword());
//
//		prop.setMaxWaitMillis(3000);
//		prop.setInitSize(dbconfig.getDbPoolMinSize()); // 
//		prop.setMaxSize(dbconfig.getDbPoolMaxSize()); // 
//
//		ConnPool connPool = ConnPoolFactory.getConnectionPool( prop );		
//		java.sql.Connection conn = null;
//		try{
//			conn = connPool.getConnection();
//			Attribute m_Manager = new Attribute(conn, tbconfig);
//			Map<Integer,String> attributeIDName = m_Manager.getAttributeIDName();
//			m_Manager.toString(attributeIDName);
//			System.exit(0);
//		}catch( Throwable th ){
//			th.printStackTrace();
//			if( conn != null )
//				try{ connPool.closeConnection(conn); } catch( Exception e ){}
//		}		
//	}	
}
