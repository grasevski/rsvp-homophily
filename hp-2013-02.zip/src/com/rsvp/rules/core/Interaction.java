package com.rsvp.rules.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.rsvp.config.Config;
import com.rsvp.log.LoggerWrapper;

public class Interaction {
	private int LHS2RHST 	= 0;
	private int LHS2RHSF 	= 0;
	private int ActiveRHS 	= 0;
	private int LHS2QT 		= 0;
	private int LHS2QF		= 0;
	private int RHS2LHST	= 0;
	private int RHS2LHSF    = 0;
	private int RHS2PT      = 0;
	private int RHS2PF      = 0;
	private int nUser       = 0;

	public Interaction () {
		
	}

	public Interaction(Connection conn) {
//		this.m_Connection = conn;
//		this.m_Database = new Database(conn);
	}

	public Interaction (int lhs2RhsT, int lhs2RhsF) {
		this.LHS2RHST = lhs2RhsT;
		this.LHS2RHSF = lhs2RhsF;
	}
	
	/**
	 * Get interaction from LHS to RHS
	 * @param sndCondition
	 * @param rcvCondition
	 * @throws SQLException
	 */
	public static Interaction getLHS2RHS(Connection conn, String sndCondition, 
			String rcvCondition, int sndGender, int sndLocation) {
		Interaction m_Interaction = null;
		
		String sql = "SELECT  response, COUNT(*) AS KISS_COUNT ";
		if(sndLocation!=Config.NULL_VALUE && sndLocation!=Config.NOT_IMPORTANT)
			sql += "FROM "+Config.TB_TRKISSUSER+sndGender+"_"+sndLocation +"  ";
		else
			sql += "FROM "+Config.TB_TRKISS_LOG +"  ";
		sql += "WHERE  "+sndCondition+" ";
		sql += "AND  "+rcvCondition+" ";
		sql += "GROUP BY response ";
		if(Config.SQL_LOG)   
			LoggerWrapper.info("Interactions", "LHS2RHS Sql: " + sql);
		PreparedStatement ps = null;
		ResultSet rs = null;			
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			int lhs2RhsT = 0;
			int lhs2RhsF = 0;
			
			while(rs.next()){
				if(rs.getString(1).equals("P")){
					lhs2RhsT = rs.getInt(2);
				} else {
					lhs2RhsF = rs.getInt(2);
				}
			}
			m_Interaction = new Interaction(lhs2RhsT, lhs2RhsF);
//			LoggerWrapper.info("Interactions", "Positive: " + lhs2RhsT + ", Negative: " + lhs2RhsF);
		} catch (SQLException e) {
			LoggerWrapper.info("interactions", "Query: "+sql);
			e.printStackTrace();
		} finally {
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}	
		return m_Interaction;
	}
	
	
	/**
	 * Get interaction from LHS to RHS
	 * @param sndCondition
	 * @param rcvCondition
	 * @throws SQLException
	 */
	public static HashMap<String, Integer>  getLHS2RHSByAgeBin(Connection conn, String sndCondition, 
			String rcvCondition, int sndGender, int sndAgeBin) {
		
		HashMap<String, Integer> interactions = new HashMap<String, Integer>();
		
		interactions.put("P", 0);
		interactions.put("N", 0);
		
		String sql = "SELECT  response, COUNT(*) AS KISS_COUNT ";
		sql += "FROM "+Config.TB_TRSUBSETKISSES+sndGender+"_"+sndAgeBin +"  ";
		sql += "WHERE "+ sndCondition+" ";
		sql += "AND  "+ rcvCondition+" ";
		sql += "GROUP BY response ";
		
		if(Config.SQL_LOG) LoggerWrapper.info("Interactions", "LHS2RHS Sql: " + sql);
		
		PreparedStatement ps = null;
		ResultSet rs = null;			
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				interactions.put(rs.getString(1), rs.getInt(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}	
		return interactions;
	}
	
	
	
	/**
	 * Get interaction from LHS to RHS
	 * @param sndCondition
	 * @param rcvCondition
	 * @throws SQLException
	 */
	public static Interaction getLHS2RHS(Connection conn, String sndCondition, String rcvCondition){
		Interaction m_Interaction = null;

		String sql = "SELECT lo.response, COUNT(*) AS KISS_COUNT "; 
		sql += "FROM "+Config.TB_TRKISS_LOG +" lo,  "+Config.TB_TRUSER+" sender, "+Config.TB_TRUSER+" receiver ";
		sql += "WHERE lo.INITIATINGUSERID=sender.USERID AND lo.TARGETUSERID=receiver.USERID ";
		sql += "AND "+sndCondition+" "; 
		sql += "AND "+rcvCondition+" ";  
		sql += "GROUP BY lo.response ";
		
//		LoggerWrapper.info("Interactions", "LHS2RHS Sql: " + sql);
		
		PreparedStatement ps = null;
		ResultSet rs = null;			
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			int lhs2RhsT = 0;
			int lhs2RhsF = 0;
			
			while(rs.next()){
				if(rs.getString(1).equals("P")){
					lhs2RhsT = rs.getInt(2);
				} else {
					lhs2RhsF = rs.getInt(2);
				}
			}
			m_Interaction = new Interaction(lhs2RhsT, lhs2RhsF);
//			LoggerWrapper.info("Interactions", "Positive: " + lhs2RhsT + ", Negative: " + lhs2RhsF);
		} catch (SQLException e) {
			LoggerWrapper.info("interactions", "Query: "+sql);
			e.printStackTrace();
		} finally {
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(rs!=null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}	
		return m_Interaction;
	}
	
	
	
	

//	public Interaction (int lhs2RhsT, int lhs2RhsF) {
//		this.LHS2RHST = lhs2RhsT;
//		this.LHS2RHSF = lhs2RhsF;
//	}
//	
//
//	public void resetVaule() {
//		this.LHS2RHST = 0;
//		this.LHS2RHSF = 0;
//		this.LHS2QT = 0;
//		this.LHS2QF = 0;
//		this.RHS2LHST = 0;
//		this.RHS2LHSF = 0;
//		this.RHS2PT = 0;
//		this.RHS2PF = 0;
//		this.nUser = 0;
//	}
//	
//	public int getSubgroupUserCount(String condition) throws SQLException {
//		String sql = "SELECT COUNT(DISTINCT(userid)) AS USER_COUNT " +
//				"FROM "+ Config.TB_TRUSER+" WHERE " + condition;
////				" AND TRAINDATASET_ID="+LearnerConfig.TRAIN_DATA; 
//		int nUser = 0;
//		PreparedStatement ps = null;
//		ResultSet rs = null;			
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				this.setnUser(rs.getInt(1));
//			}			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();
//		}
//		return nUser;
//	}
//	
//	public void getLHS2Q(String sndCondition) throws SQLException {
//		String sql = "SELECT lo.response, COUNT(*) AS KISS_COUNT " +
//				"FROM "+Config.TB_TRKISS_LOG+" lo " +
//				"WHERE " +
////				"lo.TRAINDATASET_ID = "+LearnerConfig.TRAIN_DATA+" " +
////				"AND " +
//				"lo.INITIATINGUSERID IN (" +
//					"SELECT DISTINCT(sender.userid) " +
//					"FROM "+Config.TB_TRUSER+" sender " +
//					"WHERE "+ sndCondition+ " " +
////					"AND sender.TRAINDATASET_ID=" + LearnerConfig.TRAIN_DATA + "	" +
//				") GROUP BY lo.response";
//		PreparedStatement ps = null;
//		ResultSet rs = null;			
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				if(rs.getString(1).equals("P"))
//					this.setLHS2QT(rs.getInt(2));
//				else
//					this.setLHS2QF(rs.getInt(2));
//			}			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();
//		}		
//	}
//
//	/**
//	 * Get interaction from LHS to RHS
//	 * @param sndCondition
//	 * @param rcvCondition
//	 * @throws SQLException
//	 */
//	public void getLHS2RHS(String sndCondition, String rcvCondition) throws SQLException {
//		setLHS2RHST(0);
//		setLHS2RHSF(0);
//		String sql = "SELECT lo.response, COUNT(*) AS KISS_COUNT \n " +
//				"FROM "+Config.TB_TRKISS_LOG +" lo \n" +
//				"WHERE " +
////				"lo.TRAINDATASET_ID = "+LearnerConfig.TRAIN_DATA+"\n " +
////				"AND " +
//				"lo.INITIATINGUSERID IN (\n" +
//					"SELECT DISTINCT(sender.userid) \n" +
//					"FROM "+Config.TB_TRUSER+" sender \n" +
//					"WHERE "+ sndCondition+ " \n" +
////					"AND sender.TRAINDATASET_ID=" + LearnerConfig.TRAIN_DATA + "\n " +
//				") \n" +
//				" AND \n" +
//				"lo.TARGETUSERID IN (\n" +
//				"SELECT DISTINCT(receiver.userid) \n" +
//				"FROM "+Config.TB_TRUSER+" receiver \n" +
//				"WHERE "+ rcvCondition+ " \n" +
////				"AND receiver.TRAINDATASET_ID=" + LearnerConfig.TRAIN_DATA + "	\n" +
//				") \n" +				
//				"GROUP BY lo.response \n";
////		LoggerWrapper.info("Interactions", "LHS2RHS Sql: " + sql);
//		PreparedStatement ps = null;
//		ResultSet rs = null;			
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			
//			rs = ps.executeQuery();
//		
//			while(rs.next()){
//				if(rs.getString(1).equals("P")){
//					setLHS2RHST(rs.getInt(2));
//				} else {
//					setLHS2RHSF(rs.getInt(2));
//				}
//			}
//			LoggerWrapper.info("Interactions", "Positive: " + this.getLHS2RHST());
//			LoggerWrapper.info("Interactions", "Negative: " + this.getLHS2RHSF());
//		} catch (SQLException e) {
//			LoggerWrapper.info("interactions", "Query: "+sql);
//			e.printStackTrace();
//		} finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();
//		}		
//	}
//	
//	
//	public void getLHS2RHSFromLog(String rcvCondition, int candidateSetID) throws SQLException {
//		setLHS2RHST(0);
//		setLHS2RHSF(0);
//		this.setActiveRHS(0);
//		
//		String sql = "SELECT NS_LHS_RHS_T, NS_LHS_RHS_F, RHS_ACTIVE_USER " +
//				"FROM "+Config.TB_LNINTERACTION+" receiver " +
//				"WHERE receiver.CANDIDATESET_ID = "+candidateSetID+" " +
//				"AND receiver.RCONDITION = '"+rcvCondition+"'";
//		
////		LoggerWrapper.info("Interactions", "SQL: " + sql);
//		
//		PreparedStatement ps = null;
//		ResultSet rs = null;			
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			
//			rs = ps.executeQuery();
//		
//			while(rs.next()){
//				setLHS2RHST(rs.getInt(1));
//				setLHS2RHSF(rs.getInt(2));
//				setActiveRHS(rs.getInt(3));
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();
//		}		
//	}
//	
//	public void insertLHS2RHS(String sndCondition, String rcvCondition, int LHS2RHST, int LHS2RHSF, int RHS_ACTIVE_USER, int candidateSetID ) throws SQLException {
//		String sql = "INSERT INTO "+ Config.TB_LNINTERACTION +" (SCONDITION, RCONDITION,NS_LHS_RHS_T, NS_LHS_RHS_F, RHS_ACTIVE_USER, CANDIDATESET_ID) " +
//		"VALUES('" + sndCondition + "','"+rcvCondition+"', "+LHS2RHST+",  "+LHS2RHSF+",  "+RHS_ACTIVE_USER+", "+candidateSetID+")"; 			
//		m_Database.insertQuery(sql);		
//	}
//	
//	/**
//	 * Active RHS
//	 * @param sndCondition
//	 * @param rcvCondition
//	 * @param candidateSetID
//	 * @throws SQLException
//	 */
//	public void getActiveRHS(String rcvCondition, int candidateSetID) throws SQLException {
//		setActiveRHS(0);
//		
//		String sql = "SELECT COUNT(*) AS USER_COUNT " +
//				"FROM "+Config.TB_LNACTIVEUSER+" receiver " +
//				"WHERE "+ rcvCondition+ " " +
//				"AND receiver.CANDIDATESET_ID=" + candidateSetID;
//		
//		LoggerWrapper.info("Interactions", "SQL: " + sql);
//		
//		PreparedStatement ps = null;
//		ResultSet rs = null;			
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			
//			rs = ps.executeQuery();
//		
//			while(rs.next()){
//				setActiveRHS(rs.getInt(1));
//			}
//			LoggerWrapper.info("Interactions", "Active RHS: " + this.getActiveRHS());
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();
//		}		
//	}	
//	
//	public void getLHS2RHSFromLookUpTable(String condition) throws SQLException {
//		String sql = "SELECT lk.LHS_RHS_T, lk.LHS_RHS_F " +
//				"FROM "+Config.TB_TRLOOKUP +" lk " + condition;
//
//		LoggerWrapper.info("Interactions", "LHS2RHS Sql: " + sql);
//		PreparedStatement ps = null;
//		ResultSet rs = null;			
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				this.setLHS2RHST(rs.getInt(1));
//				this.setLHS2RHSF(rs.getInt(2));
//			}
//			LoggerWrapper.info("Interactions", "Positive: " + this.getLHS2RHST());
//			LoggerWrapper.info("Interactions", "Negative: " + this.getLHS2RHSF());
//		} catch (SQLException e) {
//			LoggerWrapper.info("interactions", "Query: "+sql);
//			e.printStackTrace();
//		} finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();
//		}		
//	}		
//	
//	public void getRHS2P(String rcvCondition) throws SQLException {
//		String sql = "SELECT lo.response, COUNT(*) AS KISS_COUNT " +
//				"FROM "+ Config.TB_TRKISS_LOG+" lo " +
//				"WHERE " +
////				"lo.TRAINDATASET_ID = "+LearnerConfig.TRAIN_DATA+" " +
////				"AND " +
//				"lo.INITIATINGUSERID IN (" +
//					"SELECT DISTINCT(receiver.userid) " +
//					"FROM "+ Config.TB_TRUSER +" receiver " +
//					"WHERE "+ rcvCondition+ " " +
////					"AND receiver.TRAINDATASET_ID=" + LearnerConfig.TRAIN_DATA + "	" +
//				") GROUP BY lo.response";
//		PreparedStatement ps = null;
//		ResultSet rs = null;			
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				if(rs.getString(1).equals("P"))
//					this.setRHS2PT(rs.getInt(2));
//				else
//					this.setRHS2PF(rs.getInt(2));
//			}			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();
//		}		
//	}	
//
//	
//	public void getRHS2LHS(String sndCondition, String rcvCondition) throws SQLException {
//		String sql = "SELECT lo.response, COUNT(*) AS KISS_COUNT " +
//				"FROM "+ Config.TB_TRKISS_LOG+" lo " +
//				"WHERE " +
////				"lo.TRAINDATASET_ID = "+LearnerConfig.TRAIN_DATA+" " +
////				"AND " +
//				"lo.TARGETUSERID  IN (" +
//					"SELECT DISTINCT(sender.userid) " +
//					"FROM "+Config.TB_TRUSER+" sender " +
//					"WHERE "+ sndCondition+ " " +
////					"AND sender.TRAINDATASET_ID=" + LearnerConfig.TRAIN_DATA + "	" +
//				") " +
//				" AND " +
//				"lo.INITIATINGUSERID IN (" +
//				"SELECT DISTINCT(receiver.userid) " +
//				"FROM "+ Config.TB_TRUSER+" receiver " +
//				"WHERE "+ rcvCondition+ " " +
////				"AND receiver.TRAINDATASET_ID=" + LearnerConfig.TRAIN_DATA + "	" +
//				") " +				
//				"GROUP BY lo.response";
//		PreparedStatement ps = null;
//		ResultSet rs = null;			
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				if(rs.getString(1).equals("P"))
//					this.setRHS2LHST(rs.getInt(2));
//				else
//					this.setRHS2LHSF(rs.getInt(2));
//			}			
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();
//		}		
//	}

	public void setLHS2RHST(int lHS2RHST) {
		LHS2RHST = lHS2RHST;
	}

	public int getLHS2RHST() {
		return LHS2RHST;
	}

	public void setLHS2RHSF(int lHS2RHSF) {
		LHS2RHSF = lHS2RHSF;
	}

	public int getLHS2RHSF() {
		return LHS2RHSF;
	}

	public void setLHS2QT(int lHS2QT) {
		LHS2QT = lHS2QT;
	}

	public int getLHS2QT() {
		return LHS2QT;
	}

	public void setLHS2QF(int lHS2QF) {
		LHS2QF = lHS2QF;
	}

	public int getLHS2QF() {
		return LHS2QF;
	}

	public void setRHS2LHST(int rHS2LHST) {
		RHS2LHST = rHS2LHST;
	}

	public int getRHS2LHST() {
		return RHS2LHST;
	}

	public void setRHS2LHSF(int rHS2LHSF) {
		RHS2LHSF = rHS2LHSF;
	}

	public int getRHS2LHSF() {
		return RHS2LHSF;
	}

	public void setRHS2PT(int rHS2PT) {
		RHS2PT = rHS2PT;
	}

	public int getRHS2PT() {
		return RHS2PT;
	}

	public void setRHS2PF(int rHS2PF) {
		RHS2PF = rHS2PF;
	}

	public int getRHS2PF() {
		return RHS2PF;
	}

	public void setnUser(int nUser) {
		this.nUser = nUser;
	}

	public int getnUser() {
		return nUser;
	}

	public void setActiveRHS(int activeRHS) {
		ActiveRHS = activeRHS;
	}

	public int getActiveRHS() {
		return ActiveRHS;
	}
	
	
	public String toString() {
		String strInteraction = "";
		strInteraction += "LHS2RHST-->"+this.LHS2RHST+"\n";
		strInteraction += "LHS2RHSF-->"+this.LHS2RHSF+"\n";
		strInteraction += "LHS2QT-->"+this.LHS2QT+"\n";
		strInteraction += "LHS2QF-->"+this.LHS2QF+"\n";
		
		return strInteraction;
	}

	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		ConnPoolProperty connProperty;
//		ConnPool connPool = null;
//		Connection conn = null;
//		
//		connProperty = new ConnPoolProperty();
//		connProperty.setUrl(Config.URL);
//		connProperty.setDriverClass(Config.DRIVER);
//		connProperty.setUser(Config.DBUSER);
//		connProperty.setPassword(Config.DBPASS);
//		connProperty.setMaxWaitMillis(Config.WIAT);
//		connProperty.setInitSize(Config.MIN_POOL); 
//		connProperty.setMaxSize(Config.MAX_POOL);
//		connPool = ConnPoolFactory.getConnectionPool(connProperty);		
//			try {
//				conn = connPool.getConnection();
//				String sndCondition = "sender.GENDER_PRID=134";
//				String rcvCondition = "receiver.GENDER_PRID=135";
//				Interaction m_Interaction = Interaction.getLHS2RHS(conn, sndCondition, rcvCondition);
//				String strInteraction = m_Interaction.toString();
//				LoggerWrapper.info("Interactions", "Interaction: \n" + strInteraction);
//				System.exit(0);
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//	}
}
