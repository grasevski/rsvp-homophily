package com.rsvp.rules.core;

public class Rule implements Comparable<Rule>{
	
	private int ruleID;
	private int rulePID;
	private int userID;
	private int attributeId;
	private int sndAttributeValue;
	private int rcvAttributeValue;
	private int kissLHS2RHSF;
	private int kissLHS2RHST;
	private float srLHS2RHS;
	private float confidence;
	private String sndCondition;
	private String rcvCondition;
	private String sndQuery;
	private String rcvQuery;
	
	public Rule() {
		this.ruleID = 0;
		this.rulePID = -1;
	}
	
	public Rule (int ruleID, int rulePID, int userID, 
			int attrubuteId, int sndAttributeValue, int rcvAttributeValue,
			int kissLHS2RHST, int kissLHS2RHSF, float srLHS2RHS, 
			String sndCondition, String rcvCondition, float confidence){
		this.setRuleID(ruleID);
		this.setRulePID(rulePID);
		this.setUserID(userID);
		this.setAttributeId(attrubuteId);
		this.setSndAttributeVlaue(sndAttributeValue);
		this.setRcvAttributeVlaue(rcvAttributeValue);
		this.setKissLHS2RHSF(kissLHS2RHSF);
		this.setKissLHS2RHST(kissLHS2RHST);
		this.setSrLHS2RHS(srLHS2RHS);
		this.setSndCondition(sndCondition);
		this.setRcvCondition(rcvCondition);
		this.setConfidence(confidence);
	}

	/**
	 * This constructor is used to 
	 * @param ruleID
	 * @param finalRuleId
	 * @param srLHS2RHS
	 * @param rcvQuery
	 */
	public Rule (int ruleID, float srLHS2RHS, String rcvQuery){
		this.setRuleID(ruleID);
		this.setSrLHS2RHS(srLHS2RHS);
		this.setRcvQuery(rcvQuery);
	}
	
	public void setRuleID(int ruleID) {
		this.ruleID = ruleID;
	}

	public int getRuleID() {
		return ruleID;
	}

	public void setRulePID(int rulePID) {
		this.rulePID = rulePID;
	}

	public int getRulePID() {
		return rulePID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public int getUserID() {
		return userID;
	}

	public void setSndAttributeVlaue(int sndAttributeValue) {
		this.sndAttributeValue = sndAttributeValue;
	}

	public int getSndAttributeVlaue() {
		return sndAttributeValue;
	}

	public void setAttributeId(int attributeId) {
		this.attributeId = attributeId;
	}

	public int getAttributeId() {
		return attributeId;
	}

	public void setRcvAttributeVlaue(int rcvAttributeValue) {
		this.rcvAttributeValue = rcvAttributeValue;
	}

	public int getRcvAttributeVlaue() {
		return rcvAttributeValue;
	}

	public void setKissLHS2RHSF(int kissLHS2RHSF) {
		this.kissLHS2RHSF = kissLHS2RHSF;
	}

	public int getKissLHS2RHSF() {
		return kissLHS2RHSF;
	}

	public void setKissLHS2RHST(int kissLHS2RHST) {
		this.kissLHS2RHST = kissLHS2RHST;
	}

	public int getKissLHS2RHST() {
		return kissLHS2RHST;
	}

	public void setSrLHS2RHS(float srLHS2RHS) {
		this.srLHS2RHS = srLHS2RHS;
	}

	public float getSrLHS2RHS() {
		return srLHS2RHS;
	}

	public void setSndCondition(String sndCondition) {
		this.sndCondition = sndCondition;
	}

	public String getSndCondition() {
		return sndCondition;
	}

	public void setRcvCondition(String rcvCondition) {
		this.rcvCondition = rcvCondition;
	}

	public String getRcvCondition() {
		return rcvCondition;
	}
	
	public void setRcvQuery(String rcvQuery) {
		this.rcvQuery = rcvQuery;
	}

	public String getRcvQuery() {
		return rcvQuery;
	}

	public void setSndQuery(String sndQuery) {
		this.sndQuery = sndQuery;
	}

	public String getSndQuery() {
		return sndQuery;
	}

	public void setConfidence(float confidence) {
		this.confidence = confidence;
	}

	public float getConfidence() {
		return confidence;
	}

	public String toString() {
		String strRule = "\n";
		strRule += "RuleID:"+this.getRuleID()+"\n ";
		strRule += "SR:"+this.getSrLHS2RHS()+"\n ";
		strRule += "LHS2RHS T:"+this.getKissLHS2RHST()+"\n ";
		strRule += "LHS2RHS F:"+this.getKissLHS2RHSF()+"\n ";
		strRule += "Sender:"+this.getSndCondition()+"\n";
		strRule += "Receiver:"+this.getRcvCondition();
		return strRule;
	}

	public int compareTo(Rule rule) {
		float sub = rule.getSrLHS2RHS() - getSrLHS2RHS();
		if( sub > 0.0f ) {
			return 1;
		} else if( sub == 0.0f){
			int diff = (rule.getKissLHS2RHST()+rule.getKissLHS2RHSF())-(kissLHS2RHST+kissLHS2RHSF);
			if(diff>0)
				return 1;
			else if(diff==0)
				return 0;
			else
				return -1;
		} else {
			return -1;
		}
	}
}
