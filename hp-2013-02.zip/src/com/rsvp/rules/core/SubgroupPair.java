package com.rsvp.rules.core;

public class SubgroupPair implements Comparable<SubgroupPair> {
	private int attributeId;
	private int sndAttributeValueId;
	private int sndGenderId;
	private int rcvAttributeValueId;
	private int rcvGenderId;
	private int lhs2RHST;
	private int lhs2RHSF;
	private float successRate;
	
	public SubgroupPair() {
		
	}
	
	public SubgroupPair(int attributeId, int sndAttributeValueId, int sndGenderId, int rcvAttributeValueId,  int rcvGenderId,
			int lhs2RHST, int lhs2RHSF, float successRate ){
		this.setAttributeId(attributeId);
		this.setSndAttributeValueId(sndAttributeValueId);
		this.setSndGenderId(sndGenderId);
		this.setRcvAttributeValueId(rcvAttributeValueId);
		this.setRcvGenderId(rcvGenderId);
		this.setLhs2RHST(lhs2RHST);
		this.setLhs2RHSF(lhs2RHSF);
		this.setSuccessRate(successRate);
	}
	
	public int compareTo(SubgroupPair pair) {
		float sub = pair.getSuccessRate() - successRate;
		
		if( sub > 0.0f ) {
			return 1;
		} else if( sub == 0.0f){
			int diff = (pair.getLhs2RHST()+pair.getLhs2RHSF())-(lhs2RHST+lhs2RHSF);
			if(diff>0)
				return 1;
			else if(diff==0)
				return 0;
			else
				return -1;
		} else {
			return -1;
		}
	}

	public int compare(SubgroupPair p1, SubgroupPair p2) {
		return (int)(p1.getSuccessRate() - p2.getSuccessRate());
	}

	public boolean equals(SubgroupPair p){
		return p.getSuccessRate() == successRate;
	}

	public void setLhs2RHST(int lhs2RHST) {
		this.lhs2RHST = lhs2RHST;
	}

	public int getLhs2RHST() {
		return lhs2RHST;
	}
		
	public void setLhs2RHSF(int lhs2RHSF) {
		this.lhs2RHSF = lhs2RHSF;
	}

	public int getLhs2RHSF() {
		return lhs2RHSF;
	}

	public void setSuccessRate(float successRate) {
		this.successRate = successRate;
	}

	public float getSuccessRate() {
		return successRate;
	}

	public void setAttributeId(int attributeId) {
		this.attributeId = attributeId;
	}

	public int getAttributeId() {
		return attributeId;
	}

	public void setSndAttributeValueId(int sndAttributeValueId) {
		this.sndAttributeValueId = sndAttributeValueId;
	}

	public int getSndAttributeValueId() {
		return sndAttributeValueId;
	}

	public void setSndGenderId(int sndGenderId) {
		this.sndGenderId = sndGenderId;
	}

	public int getSndGenderId() {
		return sndGenderId;
	}

	public void setRcvAttributeValueId(int rcvAttributeValueId) {
		this.rcvAttributeValueId = rcvAttributeValueId;
	}

	public int getRcvAttributeValueId() {
		return rcvAttributeValueId;
	}

	public void setRcvGenderId(int rcvGenderId) {
		this.rcvGenderId = rcvGenderId;
	}

	public int getRcvGenderId() {
		return rcvGenderId;
	}
	
	public String toString(){
		String strSubgroupPair = "\n";
		strSubgroupPair += "AttributeId -->"+this.getAttributeId()+"\n";
		strSubgroupPair += "Sender -->"+this.getSndAttributeValueId()+" ("+this.getSndGenderId()+")\n";
		strSubgroupPair += "Receiver -->"+this.getRcvAttributeValueId()+"("+this.getRcvGenderId()+")\n";
		strSubgroupPair += "Success Rate -->"+this.getSuccessRate()+"\n";
		strSubgroupPair += "Interest -->"+this.getSuccessRate()+"\n";
		strSubgroupPair += "LHS2RHS --> T :"+this.getLhs2RHST()+" F:"+this.getLhs2RHSF()+" \n";
		return strSubgroupPair;
	}
}
