package com.rsvp.rules.dataset;


import java.sql.Connection;
import java.sql.SQLException;
//import java.text.SimpleDateFormat;
import com.rsvp.config.Config;
import com.rsvp.db.Database;
import com.rsvp.log.LoggerWrapper;
import com.rsvp.rules.core.Attribute;
import com.rsvp.rules.core.Interaction;


public class CommonDataSet {
	protected Connection m_Connection ;
	protected Database m_Database;
	protected Attribute m_Attribute;
	protected Interaction m_Interaction;
	protected final int NULL_VALUE = 1000000;
	protected final int NOT_IMPORTANT = 0;
	
//	private SimpleDateFormat fileFormat = new SimpleDateFormat( "yyyy-MM-dd");
//	private String currentDate;
	
	protected String PROFILE_QUERY = "SELECT SETID, \n" +
	"u.USERID, " + " \n" +
	" CASE \n"+ 
		"WHEN u.HDATEOFBIRTH IS NULL THEN "+NULL_VALUE+" \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=20 THEN 320 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=22 THEN 322 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=24 THEN 324 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=26 THEN 326 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=28 THEN 328 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=30 THEN 330 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=32 THEN 332 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=34 THEN 334 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=36 THEN 336 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=38 THEN 338 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=40 THEN 340 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=42 THEN 342 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=44 THEN 344 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=46 THEN 346 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=48 THEN 348 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=50 THEN 350 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=52 THEN 352 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=54 THEN 354 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=56 THEN 356 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=58 THEN 358 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=60 THEN 360 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=62 THEN 362 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=64 THEN 364 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=68 THEN 368 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=70 THEN 370 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=72 THEN 372 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=74 THEN 374 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=76 THEN 376 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=78 THEN 378 \n"+
		"WHEN TRUNC(TO_NUMBER(SUBSTR((CURRENT_TIME-U.HDATEOFBIRTH),1, INSTR(CURRENT_TIME-U.HDATEOFBIRTH,' ')))/365) <=80 THEN 380 \n"+
		"ELSE "+NULL_VALUE+" \n"+
	"END  AS AGE_BIN, \n"+
	"CASE \n"+
		"WHEN u.NUMBEROFCHILDREN IS NULL THEN "+NULL_VALUE+" \n"+
		"WHEN u.NUMBEROFCHILDREN = 0 THEN 400 \n"+
		"WHEN u.NUMBEROFCHILDREN = 1 THEN 401 \n"+
		"WHEN u.NUMBEROFCHILDREN = 2 THEN 402 \n"+
		"WHEN u.NUMBEROFCHILDREN = 3 THEN 403 \n"+
		"WHEN u.NUMBEROFCHILDREN = 4 THEN 404 \n"+
		"ELSE 405 \n"+
	"END  AS CHIRDREN_BIN, \n"+
	"CASE \n"+
		"WHEN u.HHASPHOTO IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.HHASPHOTO \n"+
	"END  AS HHASPHOTO, \n"+
	"CASE \n"+
		"WHEN u.HHASSECONDARYPHOTO IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.HHASSECONDARYPHOTO \n"+
	"END  AS HHASSECONDARYPHOTO, \n"+
	"CASE \n"+
		"WHEN u.SEEKINGPENPAL IS NULL THEN "+NULL_VALUE+" \n"+
		"WHEN u.SEEKINGPENPAL = 1 THEN 195 \n"+
		"ELSE 0 \n"+
	"END  AS SEEKINGPENPAL, \n"+ 
	"CASE \n"+
		"WHEN u.SEEKINGFRIEND IS NULL THEN "+NULL_VALUE+" \n"+
		"WHEN u.SEEKINGFRIEND = 1 THEN 196 \n"+
		"ELSE 0 \n"+
	"END  AS SEEKINGFRIEND, \n"+   
	"CASE \n"+
		"WHEN u.SEEKINGRELSHORT IS NULL THEN "+NULL_VALUE+" \n"+
		"WHEN u.SEEKINGRELSHORT = 1 THEN 197 \n"+
		"ELSE 0 \n"+
	"END  AS SEEKINGRELSHORT, \n"+   
	"CASE \n"+
		"WHEN u.SEEKINGRELLONG IS NULL THEN "+NULL_VALUE+" \n"+
		"WHEN u.SEEKINGRELLONG = 1 THEN 198 \n"+ 
		"ELSE 0 \n"+
	"END  AS SEEKINGRELLONG, \n"+  
	"CASE \n"+
		"WHEN u.HAVEPETS IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.HAVEPETS \n"+
	"END  AS HAVEPETS, \n"+				
	"CASE \n"+
		"WHEN u.OCC_INDUSTRY_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.OCC_INDUSTRY_PRID \n"+
	"END  AS OCC_INDUSTRY_PRID, \n"+				
	"CASE \n"+
		"WHEN u.OCC_LEVEL_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.OCC_LEVEL_PRID \n"+
	"END  AS OCC_LEVEL_PRID, \n"+					
	"CASE \n"+
		"WHEN u.STARSIGN_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.STARSIGN_PRID \n"+
	"END  AS STARSIGN_PRID, \n"+					
	"CASE \n"+
		"WHEN u.HAIRCOLOR_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.HAIRCOLOR_PRID \n"+
	"END  AS HAIRCOLOR_PRID, \n"+					

	"CASE \n"+
		"WHEN u.EYECOLOR_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.EYECOLOR_PRID \n"+
	"END  AS EYECOLOR_PRID, \n"+	
	"CASE "+
		"WHEN u.MARITAL_STATUS_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.MARITAL_STATUS_PRID \n"+
	"END  AS MARITAL_STATUS_PRID, \n"+	
	"CASE \n"+
		"WHEN u.BODYTYPE_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.BODYTYPE_PRID \n"+
	"END AS BODYTYPE_PRID, \n"+	
	"CASE \n"+
		"WHEN u.SEXUALITY_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.SEXUALITY_PRID \n"+
	"END AS SEXUALITY_PRID, \n"+	
	"CASE \n"+
		"WHEN u.GENDER_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.GENDER_PRID \n"+
	"END AS GENDER_PRID, \n"+	
	"CASE \n"+
		"WHEN u.NATIONALITY_PRID IS NULL THEN "+NULL_VALUE+" \n "+
		"ELSE u.NATIONALITY_PRID \n"+
	"END AS NATIONALITY_PRID, \n"+	
	"CASE \n"+
		"WHEN u.ETHNICBACKGROUND_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.ETHNICBACKGROUND_PRID \n"+
	"END AS ETHNICBACKGROUND_PRID, \n"+	
	"CASE \n"+
		"WHEN u.RELIGION_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.RELIGION_PRID \n"+
	"END AS RELIGION_PRID, \n"+	
	"CASE \n"+
		"WHEN u.PERSONALITY_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.PERSONALITY_PRID \n"+
	"END AS PERSONALITY_PRID, \n"+					
	"CASE \n"+
		"WHEN u.WANTCHILDREN_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.WANTCHILDREN_PRID \n"+
	"END AS WANTCHILDREN_PRID, \n"+
	"CASE \n"+
		"WHEN u.EDUCATION_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.EDUCATION_PRID \n"+
	"END AS EDUCATION_PRID, \n"+				
	"CASE \n"+
		"WHEN u.HAVECHILDREN_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.HAVECHILDREN_PRID \n"+
	"END AS HAVECHILDREN_PRID, \n"+				
	"CASE \n"+
		"WHEN u.SMOKE_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.SMOKE_PRID \n"+
	"END AS SMOKE_PRID, \n"+						
	"CASE \n"+
		"WHEN u.POLITICS_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.POLITICS_PRID \n"+
	"END AS POLITICS_PRID, \n"+						
	"CASE \n"+
		"WHEN u.DIET_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.DIET_PRID \n"+
	"END AS DIET_PRID, \n"+	

	"CASE \n"+
		"WHEN u.HEIGHT_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.HEIGHT_PRID \n"+
	"END AS HEIGHT_PRID, \n"+				
	"CASE \n"+
		"WHEN u.DRINK_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.DRINK_PRID \n"+
	"END AS DRINK_PRID, \n"+					
	"CASE \n"+
		"WHEN u.PLATONIC_GENDER_SOUGHT_PRID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.PLATONIC_GENDER_SOUGHT_PRID \n"+
	"END AS PLATONIC_GENDER_SOUGHT_PRID, \n"+	
	"CASE \n"+
		"WHEN u.LOC_REGIONID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.LOC_REGIONID \n"+
	"END AS LOC_REGIONID, \n"+	
	"CASE \n"+
		"WHEN u.LOC_COUNTRYID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.LOC_COUNTRYID \n"+
	"END AS LOC_COUNTRYID, \n"+	
	"CASE \n"+
		"WHEN u.LOC_DIVISIONID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.LOC_DIVISIONID \n"+
	"END AS LOC_DIVISIONID, \n"+
	"CASE \n"+
		"WHEN u.LOC_LOCUSPOINTID IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.LOC_LOCUSPOINTID \n"+
	"END AS LOC_LOCUSPOINTID, \n"+
	"CASE \n"+
		"WHEN u.HDATEOFBIRTH IS NULL THEN sysdate \n"+
		"ELSE u.HDATEOFBIRTH \n"+
	"END AS HDATEOFBIRTH, \n"+	
	"u.CREATIONDATE, \n"+
	"u.LASTUPDATE, \n"+
	"CASE \n"+
		"WHEN u.LOC_LATITUDE IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.LOC_LATITUDE \n"+
	"END AS LOC_LATITUDE, \n"+		
	"CASE \n"+
		"WHEN u.LOC_LONGITUDE IS NULL THEN "+NULL_VALUE+" \n"+
		"ELSE u.LOC_LONGITUDE \n"+
	"END AS LOC_LONGITUDE \n"+	
	"FROMTABLE \n";	

	
	public CommonDataSet(Connection conn) {
		this.m_Connection		= conn;
		this.m_Database 		= new Database(conn);
	}
	
	
	public void createTbPositiveReplies() throws SQLException {
		String tableName = Config.MASTER_TB_PREPLIES; 
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);
		
		String sql = "CREATE TABLE "+tableName+" (";
		sql += "REPLYMESSAGEID NUMBER(10,0) ";
		sql += ")";

		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
		
		sql ="INSERT ALL ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (2) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (4) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (40) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (41) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (42) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (43) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (60) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (62) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (100) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (101) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (102) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (103) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (104) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (105) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (115) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (116) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (117) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (118) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (120) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (161) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (162) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (163) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (180) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (181) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (119) ";
		sql += "INTO "+tableName+" (REPLYMESSAGEID) VALUES (121) ";
   		sql += "SELECT * FROM dual";
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
	}
	
	/**
	 * Print lookup tables
	 * @throws SQLException 
	 */
//	public void printLookUpTable() throws SQLException {
//		String sql = "SELECT ";
//		sql += "lp.ATTRIBUTE_ID, lp.LHS_VALUE_ID, lp.LHS_GENDER, lp.RHS_VALUE_ID, lp.RHS_GENDER, "; 
//		sql += "lp.LHS_Q_T, lp.LHS_Q_F, lp.LHS_RHS_T, lp.LHS_RHS_F, ROUND(lp.RCV_INTEREST, 4), ROUND(lp.SND_INTEREST, 4) ";
//		sql += "FROM ";
//		sql += "E_TRAIN_LOOKUP lp ";
//		sql += "ORDER BY lp.ATTRIBUTE_ID, lp.LHS_VALUE_ID, lp.LHS_GENDER, lp.RHS_VALUE_ID, lp.RHS_GENDER ASC"; 
//		
//		this.m_Attribute.loadAttributeTable();
//		
//		Map<Integer,String> property = Attribute.getAttributeIDNamePair();
//		
//		currentDate = fileFormat.format(new Date());
//		String lookUpFile = "doc/"+ currentDate + ".lookup.xls";
//		
//		PrintWriter writer = null;
//		try {
//			writer = new PrintWriter( new FileWriter(lookUpFile, true));
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		
//		PreparedStatement ps = null;
//		ResultSet rs = null;	
//		try {
//			ps = this.m_Connection.prepareStatement(sql);
//			rs = ps.executeQuery();
//			while(rs.next()){
//				if(property.containsKey(rs.getInt(1))) { 
//					String AttributeName = property.get(rs.getInt(1));
//					String lhsValueName = "Not Important";
//					if(rs.getInt(2)!=0) lhsValueName = m_Attribute.getAttributeNameByID(rs.getInt(1), rs.getInt(2));
//					String lhsGender = "Male";
//					if(rs.getInt(3)==135) lhsGender = "Female";
//					String rhsValueName = "Not Important";
//					if(rs.getInt(4)!=0)  rhsValueName = m_Attribute.getAttributeNameByID(rs.getInt(1), rs.getInt(4));
//					String rhsGender = "Male";
//					if(rs.getInt(5)==135) rhsGender = "Female";
//					String msg = AttributeName+"|"+lhsValueName+"|"+lhsGender+"|"+rhsValueName+"|"+rhsGender+"|";
//					msg += rs.getInt(6)+"|"+rs.getInt(7)+"|"+rs.getInt(8)+"|"+rs.getInt(9)+"|";
//					msg += rs.getFloat(10)+"|"+rs.getFloat(11); 
//					writer.println( msg );
//				}
//			}
//		} catch (SQLException e1) {
//			e1.printStackTrace();
//		}finally {
//			if(ps!=null)
//				ps.close();
//			if(rs!=null)
//				rs.close();			
//		}
//		this.m_Attribute.unloadAttbibuteTable();
//		writer.close();
//	}
}
