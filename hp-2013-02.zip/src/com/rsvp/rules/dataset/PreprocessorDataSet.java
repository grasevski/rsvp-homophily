package com.rsvp.rules.dataset;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import com.rsvp.config.Config;
import com.rsvp.log.LoggerWrapper;
import com.rsvp.rules.core.Attribute;

public class PreprocessorDataSet extends CommonDataSet{
	
	public String MASTER_TB_KISS			= Config.MASTER_TB_KISS; 
	public String MASTER_TB_USER			= Config.MASTER_TB_USER;
	
	public String MASTER_TB_PICTURE			= Config.MASTER_TB_PICTURE;
	public String MASTER_TB_LOCUSPOINT		= Config.MASTER_TB_LOCUSPOINT;
	public String MASTER_TB_PROPERTY   		= Config.MASTER_TB_PROPERTY;
//	public String MASTER_TB_CONTACT			= "USERCONTACT";
//	public String MASTER_TB_BLOCKED			= "UC_BLOCKEDCONTACT";
	
	public String TRAIN_START_DATE;
	public String TRAIN_END_DATE;
	
	
	public PreprocessorDataSet(Connection conn, String trainStartDate, String trainEndDate) {
		super(conn);
		this.setTableName();
		this.TRAIN_START_DATE = trainStartDate;
		this.TRAIN_END_DATE = trainEndDate;
	}
	
	
	private void setTableName() {
		if(!Config.DB_LINK_NAME.equals("")) {
			MASTER_TB_KISS 				= MASTER_TB_KISS+"@"+Config.DB_LINK_NAME;
			MASTER_TB_USER 				= MASTER_TB_USER+"@"+Config.DB_LINK_NAME;
			MASTER_TB_PICTURE 			= MASTER_TB_PICTURE+"@"+Config.DB_LINK_NAME;
			MASTER_TB_LOCUSPOINT 		= MASTER_TB_LOCUSPOINT+"@"+Config.DB_LINK_NAME;
			MASTER_TB_PROPERTY 			= MASTER_TB_PROPERTY+"@"+Config.DB_LINK_NAME;
//			MASTER_TB_CONTACT 			= MASTER_TB_CONTACT+"@"+Config.DB_LINK_NAME;
//			MASTER_TB_BLOCKED 			= MASTER_TB_BLOCKED+"@"+Config.DB_LINK_NAME;
		}
		
		if(!Config.DB_NAME.equals("")) {
			MASTER_TB_KISS 				= Config.DB_NAME+"."+MASTER_TB_KISS;
			MASTER_TB_USER 				= Config.DB_NAME+"."+MASTER_TB_USER;
			MASTER_TB_PICTURE 			= Config.DB_NAME+"."+MASTER_TB_PICTURE;
			MASTER_TB_LOCUSPOINT 		= Config.DB_NAME+"."+MASTER_TB_LOCUSPOINT;
			MASTER_TB_PROPERTY 			= Config.DB_NAME+"."+MASTER_TB_PROPERTY;
//			MASTER_TB_CONTACT 			= Config.DB_NAME+"."+MASTER_TB_CONTACT;
//			MASTER_TB_BLOCKED 			= Config.DB_NAME+"."+MASTER_TB_BLOCKED;
		}
	}

	/**
	 * Register train data set
	 * @return int profile set id
	 * @throws SQLException 
	 */
	public int registerTrainDataSet() throws SQLException {
		int trainDataSetID = 0;
		trainDataSetID = m_Database.getLastID("TRAINDATASET_ID", Config.TB_TRDATASET);
		String sql = "INSERT INTO " + Config.TB_TRDATASET +"(TRAINDATASET_ID, FROM_DATE, TO_DATE, SUMMARY, CREATED) " +
				"VALUES ("+trainDataSetID+", '"+this.TRAIN_START_DATE+"', '"+this.TRAIN_END_DATE+ 
				"', 'Train data set from "+this.TRAIN_START_DATE+" to  "+this.TRAIN_END_DATE+"', sysdate)";

		if(Config.SQL_LOG)
			LoggerWrapper.info("dataset", "SQL: " + sql);	
		m_Database.insertQuery(sql);
		return trainDataSetID;
	}	
	
	
	/**
	 * Generate attribute table for training
	 * @throws SQLException
	 */
	public void generatePropertyTable() throws SQLException {
		String tableName = Config.TB_TRPROPERTY;
		Map<Integer,String> attIdNameSet = Attribute.getAttributeIDNamePair();
		Set<Entry<Integer,String>> s = attIdNameSet.entrySet();
        Iterator<Entry<Integer,String>>  it=s.iterator();
        while(it.hasNext()) {
        	Entry<Integer,String> entry = it.next();
        	int propertyID = entry.getKey();
        	String propertyFieldName = entry.getValue();
//        	LoggerWrapper.info("rule-learner", "Sql:"+propertyID + " "+ propertyFieldName);
            if(propertyID==50) {
            	String sql = "INSERT INTO "+ tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 320, '~20')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 322, '~22')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 324, '~24')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 326, '~26')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 328, '~28')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 330, '~30')";  
            	this.m_Database.insertQuery(sql);

            	
            	sql = "INSERT INTO "+ tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 332, '~32')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 334, '~34')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 336, '~36')";  
            	this.m_Database.insertQuery(sql);
            	
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 338, '~38')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 340, '~40')";  
            	this.m_Database.insertQuery(sql);
            	
            	sql = "INSERT INTO "+ tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 342, '~42')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 344, '~44')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 346, '~46')";  
            	this.m_Database.insertQuery(sql);
            	
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 348, '~48')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 350, '~50')";  
            	this.m_Database.insertQuery(sql);
            	
            	
            	sql = "INSERT INTO "+ tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 352, '~52')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 354, '~54')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 356, '~56')";  
            	this.m_Database.insertQuery(sql);
            	
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 358, '~58')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 360, '~60')";  
            	this.m_Database.insertQuery(sql);
            	
            	sql = "INSERT INTO "+ tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 362, '~62')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 364, '~64')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 366, '~66')";  
            	this.m_Database.insertQuery(sql);
            	
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 368, '~68')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 370, '~70')";  
            	this.m_Database.insertQuery(sql);
            	
            	sql = "INSERT INTO "+ tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 372, '~72')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 374, '~74')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 376, '~76')";  
            	this.m_Database.insertQuery(sql);
            	
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 378, '~78')";  
            	this.m_Database.insertQuery(sql);
            	
               	sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " VALUES ('"+propertyFieldName+"',"+propertyID+", 'AGE BIN', 1, 380, '~80')";  
            	this.m_Database.insertQuery(sql);
            	
            	
            } else if (propertyID==51) { //LOCUSPOINT ID
               	String sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " SELECT '"+propertyFieldName+"' AS FIELDNAME,"+propertyID+" AS PROPERTYID, 'LOCATION' AS PROPERTYNAME, 1 AS STATUS, LOCUSPOINTID, LOCUSPOINTNAME " +
            			"FROM "+MASTER_TB_LOCUSPOINT+ " WHERE LOCUSPOINTID IN (SELECT DISTINCT LOCUSPOINTID FROM "+MASTER_TB_USER+")";   
            	this.m_Database.insertQuery(sql);
            } else {
               	String sql = "INSERT INTO "+tableName + " (FIELDNAME,PROPERTYID,PROPERTYNAME,STATUS,VALUEID,VALUENAME) ";
            	sql += " SELECT '"+propertyFieldName+"' AS FIELDNAME,"+propertyID+" AS PROPERTYID, PROPERTYNAME, 1 AS STATUS, PROPERTYID, PROPERTYNAME " +
            			"FROM "+MASTER_TB_PROPERTY + " WHERE PROPTYPEID="+propertyID;   
            	this.m_Database.insertQuery(sql);            	
            }
        }
	}
	
	/**
	 * Generate kiss log from master log table (e.g. RSVP_0410.SR_KISS)
	 * If the kiss is read by the receiver and sent positive replies, the 
	 * interaction is classified as positive one
	 * If the kiss is read by the receiver and sent negative replies 
	 * or not sent replies is classified as negative one.
	 * 
	 * @throws SQLException 
	 */
	public void createTbTrainKissLog() throws SQLException {
		String tableName = Config.TB_TRKISS_LOG; 
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);

		String sql = "CREATE TABLE "+tableName+" AS " +
		"SELECT " +
		"k.ID, "+
		"k.INITIATINGUSERID, "+
		"k.TARGETUSERID, k.CREATED, "+
		"CASE " +
		" WHEN k.replymessageid IN(SELECT REPLYMESSAGEID FROM "+ Config.MASTER_TB_PREPLIES+") THEN 'P' " +
		" ELSE 'N' " +
		"END AS RESPONSE " +
		"FROM "+MASTER_TB_KISS+" k "+
		"WHERE " +
//		"k.KISSREADBYTARGET = 1 AND " +
//		"KISSREADBYTARGETDATE IS NOT NULL AND " +
		"k.CREATED>=TO_DATE('"+ this.TRAIN_START_DATE + "','DD/MM/YY') AND " +
		"k.CREATED<=TO_DATE('"+ this.TRAIN_END_DATE + "','DD/MM/YY') " +
		"ORDER BY k.CREATED ASC";	
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("dataset", "SQL: " + sql);	
		m_Database.updateQuery(sql);
		
		sql ="CREATE INDEX IDX_"+tableName+" ON "+tableName+" ('RESPONSE', 'INITIATINGUSERID', 'TARGETUSERID', 'ID','TRAINDATASET_ID')";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.insertQuery(sql); 
	}
	

	/**
	 * Generate train users' profiles, where the train users are 
	 * the users who send actions or sent replies 
	 * @param trainDataSetID
	 * @throws SQLException 
	 */
	public void createTbTrainUserProfile() throws SQLException {
		String tableName = Config.TB_TRUSER;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);

		String trainSql = PROFILE_QUERY;
		trainSql = trainSql.replace("SETID,", "");
		trainSql = trainSql.replace("CURRENT_TIME", "TO_DATE('"+this.TRAIN_END_DATE+"','DD/MM/YY')");
		trainSql = trainSql.replace("FROMTABLE", " FROM "+MASTER_TB_USER+" u ");
		String sql="CREATE TABLE "+ tableName +" AS " + trainSql +
			"WHERE " +
			"u.USERID IN("+
				"SELECT USERID FROM " +
				"( " +
				  "SELECT DISTINCT KS.TARGETUSERID AS USERID FROM " + Config.TB_TRKISS_LOG +  " KS "  +
				  "UNION " +
				  "SELECT DISTINCT KS.INITIATINGUSERID AS USERID FROM "+ Config.TB_TRKISS_LOG + " KS " +
				"))";		
		if(Config.SQL_LOG)
			LoggerWrapper.info("train", "SQL: " + sql);
		
		m_Database.updateQuery(sql);
		
		sql ="CREATE INDEX IDX_"+tableName+" ON "+tableName+" ('USERID', 'AGE_BIN', 'BODYTYPE_PRID', 'CHIRDREN_BIN', 'DIET_PRID', 'DRINK_PRID', " +
		"'EDUCATION_PRID', 'ETHNICBACKGROUND_PRID', 'EYECOLOR_PRID', 'SEEKINGFRIEND', 'GENDER_PRID', 'HAIRCOLOR_PRID', 'HAVECHILDREN_PRID', " +
		"'HAVEPETS', 'HEIGHT_PRID', 'HHASPHOTO',  'HHASSECONDARYPHOTO', 'OCC_INDUSTRY_PRID', 'OCC_LEVEL_PRID', 'LOC_LOCUSPOINTID', " +
		"'SEEKINGRELLONG','MARITAL_STATUS_PRID',  'SEEKINGPENPAL', 'PERSONALITY_PRID', 'POLITICS_PRID', 'RELIGION_PRID','SEXUALITY_PRID', " +
		" 'PLATONIC_GENDER_SOUGHT_PRID','SEEKINGRELSHORT','SMOKE_PRID', 'STARSIGN_PRID', 'WANTCHILDREN_PRID' )";
		m_Database.updateQuery(sql); 
	}
	
	/**
	 * Create threshold for minimum interaction\
	 * http://edis.ifas.ufl.edu/pd006
	 */
	public void createTbTrainThreshold() throws SQLException {
		String tableName = Config.TB_TRTHRESHOLD;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);

		String sql = "CREATE TABLE "+tableName+" AS \n";
		sql += "SELECT SND_GENDER, RCV_GENDER, INTERACTION, ";
		sql += "(6.634746*0.5*0.5/0.0009)/(1+((6.634746*0.5*0.5/0.0009)-1)/INTERACTION) AS THRESHOLD_99_3, \n"; 
		sql += "(3.8416*0.5*0.5/0.0009)/(1+((3.8416*0.5*0.5/0.0009)-1)/INTERACTION) AS THRESHOLD_95_3, \n";
		sql += "(6.634746*0.5*0.5/0.0025)/(1+((6.634746*0.5*0.5/0.0025)-1)/INTERACTION) AS THRESHOLD_99_5, \n"; 
		sql += "(3.8416*0.5*0.5/0.0025)/(1+((3.8416*0.5*0.5/0.0025)-1)/INTERACTION) AS THRESHOLD_95_5\n ";		
		sql += "FROM \n";
		sql += "( \n";
		sql += "SELECT  S.GENDER_PRID AS SND_GENDER, R.GENDER_PRID AS RCV_GENDER, COUNT(*) AS INTERACTION FROM "+Config.TB_TRKISS_LOG+" L, "+Config.TB_TRUSER+" S, "+Config.TB_TRUSER+" R \n";
		sql += "WHERE L.INITIATINGUSERID=S.USERID AND L.TARGETUSERID=R.USERID \n";
		sql += "GROUP BY S.GENDER_PRID, R.GENDER_PRID \n";
		sql += ") "; 
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("train", "SQL: " + sql);	
		
		m_Database.insertQuery(sql);
	}

	
	/**
	 * Interactions between LHS and RHS
	 * LHS and RHS is defined by one attribute value
	 *  
	 * @param typeID
	 * @param typeName
	 * @throws SQLException
	 */
	public void generateTrainLHS2RHSInteraction(int typeID, String typeName) throws SQLException {
		String tableName = Config.TB_TRLHS2RHS;
		
		String sql = "INSERT INTO "+ tableName +" "+
					"SELECT "+typeID+" AS ATRIBUTEID, P1."+typeName+" AS LHS_VALUE_ID, " +
					"P1.GENDER_PRID AS LHS_GENDER, P2."+typeName+" RHS_VALUE_ID, "+
					"P2.GENDER_PRID AS RHS_GENDER, lo.RESPONSE, COUNT(*) AS INT_COUNT " +
					"FROM "+ Config.TB_TRKISS_LOG +" lo, "+ Config.TB_TRUSER + " P1, "+ Config.TB_TRUSER +" P2	" +
					"WHERE lo.INITIATINGUSERID=P1.USERID "+
//					"AND P1."+typeName+" NOT IN ("+NOT_IMPORTANT+", "+NULL_VALUE+") AND P2."+typeName+" NOT IN("+NOT_IMPORTANT+", "+NULL_VALUE+") " +
					"AND lo.TARGETUSERID=P2.USERID " +
					"GROUP BY P1."+typeName+", P1.GENDER_PRID, P2."+typeName+", P2.GENDER_PRID, lo.RESPONSE " +
					"ORDER BY  P1."+typeName+" ASC, P1.GENDER_PRID, P2."+typeName+", P2.GENDER_PRID ASC";
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("train", "SQL: " + sql);	
		m_Database.insertQuery(sql);
	}

	/**
	 * Get # of users in RHS subgroup
	 * 
	 * @param typeID
	 * @param typeName
	 */
	public void generateTrainSubgroupUserCount(int typeID, String typeName){
		String tableName = Config.TB_TRSUBGROUP_USER;
		
		String sql = "INSERT INTO "+ tableName +" ";
		sql += "SELECT "+typeID+" AS ATRIBUTEID, U."+typeName+" AS VALUE_ID, ";
		sql += "U.GENDER_PRID AS GENDER, COUNT(U.USERID) AS USER_COUNT ";
		sql += "FROM "+ Config.TB_TRUSER + " U ";
		sql += "WHERE U.USERID IN (SELECT K.TARGETUSERID FROM "+ Config.TB_TRKISS_LOG + " K) ";
		sql += "GROUP BY U.GENDER_PRID, U."+typeName+" ";
		sql += "ORDER BY U.GENDER_PRID, U."+typeName+" ASC";
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("train", "SQL: " + sql);	
		try {
			m_Database.insertQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Generate lookup 
	 * @param trainDataSetID
	 * @throws SQLException
	 */
	public void createTbTrainLookup() throws SQLException {
		
		String tableName = Config.TB_TRLOOKUP;
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);

		String sql= "CREATE TABLE "+ tableName+" AS \n";
		sql +="SELECT T1.*, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='P' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_VALUE_ID= LHS_VALUE_ID AND T1.LHS_GENDER=LHS_GENDER AND  T1.RHS_VALUE_ID=RHS_VALUE_ID AND T1.RHS_GENDER=RHS_GENDER) AS LHS2RHS_T, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='N' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_VALUE_ID= LHS_VALUE_ID AND T1.LHS_GENDER=LHS_GENDER AND  T1.RHS_VALUE_ID=RHS_VALUE_ID AND T1.RHS_GENDER=RHS_GENDER) AS LHS2RHS_F, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_VALUE_ID= LHS_VALUE_ID AND T1.LHS_GENDER=LHS_GENDER AND T1.RHS_GENDER=RHS_GENDER) AS LHS2Q, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='P' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_VALUE_ID= LHS_VALUE_ID AND T1.LHS_GENDER=LHS_GENDER AND T1.RHS_GENDER=RHS_GENDER) AS LHS2Q_T, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='N' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_VALUE_ID= LHS_VALUE_ID AND T1.LHS_GENDER=LHS_GENDER AND T1.RHS_GENDER=RHS_GENDER) AS LHS2Q_F, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE T1.ATTRIBUTE_ID = ATTRIBUTE_ID AND T1.RHS_GENDER=RHS_GENDER AND T1.LHS_GENDER=LHS_GENDER) AS P2Q, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='P' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.RHS_GENDER=RHS_GENDER AND T1.LHS_GENDER=LHS_GENDER) AS P2Q_T, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='N' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.RHS_GENDER=RHS_GENDER AND T1.LHS_GENDER=LHS_GENDER) AS P2Q_F, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE T1.ATTRIBUTE_ID = ATTRIBUTE_ID AND T1.RHS_GENDER=RHS_GENDER AND T1.LHS_GENDER=LHS_GENDER AND T1.RHS_VALUE_ID=RHS_VALUE_ID) AS P2RHS, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='P' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.RHS_GENDER=RHS_GENDER AND T1.RHS_VALUE_ID=RHS_VALUE_ID) AS P2RHS_T, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='N' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.RHS_GENDER=RHS_GENDER AND T1.RHS_VALUE_ID=RHS_VALUE_ID) AS P2RHS_F, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_VALUE_ID= RHS_VALUE_ID AND T1.LHS_GENDER=RHS_GENDER AND  T1.RHS_VALUE_ID=LHS_VALUE_ID AND T1.RHS_GENDER=LHS_GENDER) AS RHS2LHS, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='P' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_VALUE_ID= RHS_VALUE_ID AND T1.LHS_GENDER=RHS_GENDER AND  T1.RHS_VALUE_ID=LHS_VALUE_ID AND T1.RHS_GENDER=LHS_GENDER) AS RHS2LHS_T, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='N' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_VALUE_ID= RHS_VALUE_ID AND T1.LHS_GENDER=RHS_GENDER AND  T1.RHS_VALUE_ID=LHS_VALUE_ID AND T1.RHS_GENDER=LHS_GENDER) AS RHS2LHS_F, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_GENDER=RHS_GENDER AND  T1.RHS_VALUE_ID=LHS_VALUE_ID AND T1.RHS_GENDER=LHS_GENDER) AS RHS2P, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='P' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_GENDER=RHS_GENDER AND  T1.RHS_VALUE_ID=LHS_VALUE_ID AND T1.RHS_GENDER=LHS_GENDER) AS RHS2P_T, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='N' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_GENDER=RHS_GENDER AND  T1.RHS_VALUE_ID=LHS_VALUE_ID AND T1.RHS_GENDER=LHS_GENDER) AS RHS2P_F, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_GENDER=RHS_GENDER AND T1.RHS_GENDER=LHS_GENDER) AS Q2P, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='P' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_GENDER=RHS_GENDER AND T1.RHS_GENDER=LHS_GENDER) AS Q2P_T, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='N' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID  AND T1.LHS_GENDER=RHS_GENDER AND T1.RHS_GENDER=LHS_GENDER) AS Q2P_F, \n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_GENDER=RHS_GENDER AND T1.RHS_VALUE_ID=LHS_VALUE_ID AND T1.RHS_GENDER=LHS_GENDER) AS Q2LHS,\n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='P' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_GENDER=RHS_GENDER AND  T1.RHS_VALUE_ID=LHS_VALUE_ID AND T1.RHS_GENDER=LHS_GENDER) AS Q2LHS_T,\n";
		sql +="(SELECT  CASE WHEN SUM(INT_COUNT) IS NULL THEN 0 ELSE SUM(INT_COUNT) END FROM "+Config.TB_TRLHS2RHS+" WHERE RESPONSE='N' AND T1.ATTRIBUTE_ID=ATTRIBUTE_ID AND T1.LHS_GENDER=RHS_GENDER AND  T1.RHS_VALUE_ID=LHS_VALUE_ID AND T1.RHS_GENDER=LHS_GENDER) AS Q2LHS_F,\n";
		sql +="(SELECT USER_COUNT FROM "+Config.TB_TRSUBGROUP_USER+" WHERE ATTRIBUTE_ID=T1.ATTRIBUTE_ID AND VALUE_ID=T1.LHS_VALUE_ID AND GENDER=T1.LHS_GENDER) AS LHS_USERS, \n";
		sql +="(SELECT USER_COUNT FROM "+Config.TB_TRSUBGROUP_USER+" WHERE ATTRIBUTE_ID=T1.ATTRIBUTE_ID AND VALUE_ID=T1.RHS_VALUE_ID AND GENDER=T1.RHS_GENDER) AS RHS_USERS, \n";
		sql +="(SELECT SUM(USER_COUNT) FROM "+Config.TB_TRSUBGROUP_USER+" WHERE ATTRIBUTE_ID=T1.ATTRIBUTE_ID AND GENDER=T1.LHS_GENDER) AS P_USERS, \n";
		sql +="(SELECT SUM(USER_COUNT) FROM "+Config.TB_TRSUBGROUP_USER+" WHERE ATTRIBUTE_ID=T1.ATTRIBUTE_ID AND GENDER=T1.RHS_GENDER) AS Q_USERS \n";
		sql +="FROM (SELECT ATTRIBUTE_ID, LHS_VALUE_ID,LHS_GENDER,RHS_VALUE_ID,RHS_GENDER, SUM(INT_COUNT) AS LHS2RHS FROM "+Config.TB_TRLHS2RHS+"  GROUP BY ATTRIBUTE_ID, LHS_VALUE_ID, LHS_GENDER, RHS_VALUE_ID, RHS_GENDER ORDER BY ATTRIBUTE_ID, LHS_VALUE_ID, LHS_GENDER, RHS_VALUE_ID, RHS_GENDER ASC) T1 \n";

		//WHEREATTRIBUTE_ID=13 AND LHS_GENDER<>RHS_GENDER 
		
//		sql += "SELECT TB3.*, \n"; 
//		sql += "( \n";
//		sql += "  SELECT \n"; 
//		sql += "  TB4.LHS2RHS_F \n"; 
//		sql += "  FROM \n";
//		sql += "  ( \n";
//		sql += "  SELECT \n"; 
//		sql += "    TB1.ATTRIBUTE_ID, TB1.LHS_VALUE_ID, TB1.LHS_GENDER, TB1.RHS_VALUE_ID, TB1.RHS_GENDER, \n"; 
//		sql += "    TB1.INT_COUNT AS LHS2RHS_F, CASE WHEN TB2.INT_COUNT IS NULL THEN 0 ELSE TB2.INT_COUNT  END  AS LHS2RHS_T \n";   
//		sql += "    FROM  \n";
//		sql += "    (SELECT * FROM "+ Config.TB_TRLHS2RHS+"  WHERE RESPONSE='N') TB1 \n";
//		sql += "    LEFT JOIN \n";
//		sql += "    (SELECT * FROM "+ Config.TB_TRLHS2RHS+"  WHERE RESPONSE='P') TB2 \n";
//		sql += "    ON \n";
//		sql += "    TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID \n";
//		sql += "    AND TB1.LHS_VALUE_ID=TB2.LHS_VALUE_ID \n";
//		sql += "    AND TB1.LHS_GENDER=TB2.LHS_GENDER \n";
//		sql += "    AND TB1.RHS_VALUE_ID=TB2.RHS_VALUE_ID \n";
//		sql += "    AND TB1.RHS_GENDER = TB2.RHS_GENDER \n";
//		sql += "  ) TB4 \n";
//		sql += "  WHERE  TB3.ATTRIBUTE_ID = TB4.ATTRIBUTE_ID \n";
//		sql += "  AND TB3.LHS_VALUE_ID=TB4.RHS_VALUE_ID \n";
//		sql += "  AND TB3.LHS_GENDER=TB4.RHS_GENDER \n";
//		sql += "  AND TB3.RHS_VALUE_ID=TB4.LHS_VALUE_ID \n";
//		sql += "  AND TB3.RHS_GENDER = TB4.LHS_GENDER \n";    
//		sql += ") AS RHS2LHS_F , \n";
//		sql += "( \n";
//		sql += "  SELECT \n"; 
//		sql += "  TB4.LHS2RHS_T AS RHS2LHS_T \n"; 
//		sql += "  FROM \n";
//		sql += "  ( \n";
//		sql += "  SELECT \n"; 
//		sql += "    TB1.ATTRIBUTE_ID, TB1.LHS_VALUE_ID, TB1.LHS_GENDER, TB1.RHS_VALUE_ID, TB1.RHS_GENDER, \n"; 
//		sql += "    TB1.INT_COUNT AS LHS2RHS_F, CASE WHEN TB2.INT_COUNT IS NULL THEN 0 ELSE TB2.INT_COUNT  END  AS LHS2RHS_T \n";   
//		sql += "    FROM  \n";
//		sql += "    (SELECT * FROM "+ Config.TB_TRLHS2RHS+"  WHERE RESPONSE='N') TB1 \n";
//		sql += "    LEFT JOIN \n";
//		sql += "    (SELECT * FROM "+ Config.TB_TRLHS2RHS+"  WHERE RESPONSE='P') TB2 \n";
//		sql += "    ON \n";
//		sql += "    TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID \n";
//		sql += "    AND TB1.LHS_VALUE_ID=TB2.LHS_VALUE_ID \n";
//		sql += "    AND TB1.LHS_GENDER=TB2.LHS_GENDER \n";
//		sql += "    AND TB1.RHS_VALUE_ID=TB2.RHS_VALUE_ID \n";
//		sql += "    AND TB1.RHS_GENDER = TB2.RHS_GENDER \n";
//		sql += " ) TB4 \n";
//		sql += "  WHERE  TB3.ATTRIBUTE_ID = TB4.ATTRIBUTE_ID \n";
//		sql += "  AND TB3.LHS_VALUE_ID=TB4.RHS_VALUE_ID \n";
//		sql += "  AND TB3.LHS_GENDER=TB4.RHS_GENDER \n";
//		sql += "  AND TB3.RHS_VALUE_ID=TB4.LHS_VALUE_ID \n";
//		sql += "  AND TB3.RHS_GENDER = TB4.LHS_GENDER \n";    
//		sql += ") AS RHS2LHS_T  \n";
//		sql += "FROM \n";
//		sql += "( \n";
//		sql += "  SELECT \n"; 
//		sql += "  TB1.ATTRIBUTE_ID, TB1.LHS_VALUE_ID, TB1.LHS_GENDER, TB1.RHS_VALUE_ID, TB1.RHS_GENDER, \n"; 
//		sql += "  TB1.INT_COUNT AS LHS2RHS_F, CASE WHEN TB2.INT_COUNT IS NULL THEN 0 ELSE TB2.INT_COUNT  END  AS LHS2RHS_T \n";   
//		sql += "  FROM  \n";
//		sql += "  (SELECT * FROM "+ Config.TB_TRLHS2RHS+"  WHERE RESPONSE='N') TB1 \n";
//		sql += "  LEFT JOIN \n";
//		sql += "  (SELECT * FROM "+ Config.TB_TRLHS2RHS+"  WHERE RESPONSE='P') TB2 \n";
//		sql += "  ON \n";
//		sql += "  TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID \n";
//		sql += "  AND TB1.LHS_VALUE_ID=TB2.LHS_VALUE_ID \n";
//		sql += "  AND TB1.LHS_GENDER=TB2.LHS_GENDER \n";
//		sql += "  AND TB1.RHS_VALUE_ID=TB2.RHS_VALUE_ID \n";
//		sql += "  AND TB1.RHS_GENDER = TB2.RHS_GENDER \n";
//		sql += ") TB3 \n";
		if(Config.SQL_LOG)
			LoggerWrapper.info("train", "SQL: " + sql);	
		m_Database.insertQuery(sql);
	}	
	

	
	/**
	 * Create train dataset table
	 * @throws SQLException
	 */
	public void createTbTrainDataset() throws SQLException {
		String tableName = Config.TB_TRDATASET; 
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);
		
		String sql = "CREATE TABLE "+tableName+" (";
		sql += "TRAINDATASET_ID NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "FROM_DATE VARCHAR2(4000 BYTE),";
		sql += "TO_DATE VARCHAR2(4000 BYTE),";
		sql += "SUMMARY VARCHAR2(4000 BYTE), ";
		sql += "CREATED TIMESTAMP (3) NOT NULL ENABLE, ";
		sql += "S_KISS_LOG TIMESTAMP (3), ";
		sql += "E_KISS_LOG TIMESTAMP (3), ";
		sql += "S_PROFILE TIMESTAMP (3), ";
		sql += "E_PROFILE TIMESTAMP (3), ";	
		sql += "S_INTERACTION TIMESTAMP (3), ";
		sql += "E_INTERACTION TIMESTAMP (3), ";			
		sql += "S_LOOKUP TIMESTAMP (3), ";
		sql += "E_LOOKUP TIMESTAMP (3), ";		
		sql += "CONSTRAINT IDX_"+tableName+"_PK PRIMARY KEY (TRAINDATASET_ID)";
		sql += ")";

		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.insertQuery(sql);
	}
	
	/**
	 * Create attribute table
	 * @throws SQLException
	 */
	public void createTbTrainProperty() throws SQLException {
		String tableName = Config.TB_TRPROPERTY;
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);
		
		String sql = "CREATE TABLE "+tableName+" (";
		sql += "PROPERTYID NUMBER(10,0) NOT NULL ENABLE,";
		sql += "FIELDNAME VARCHAR2(255 BYTE), ";
		sql += "PROPERTYNAME VARCHAR2(255 BYTE) NOT NULL ENABLE, ";
		sql += "VALUEID NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "VALUENAME VARCHAR2(255 BYTE) NOT NULL ENABLE,";
		sql += "STATUS NUMBER(1,0) NOT NULL ENABLE";
		sql += ")";

		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.insertQuery(sql);

		sql ="CREATE INDEX IDX_"+tableName+" ON "+tableName+"('PROPERTYID', 'PROPERTYNAME', 'VALUEID', 'VALUENAME')";
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.insertQuery(sql); 
//		System.exit(0);
	}

	public void createTbTrainLHS2RHS() throws SQLException {
		String tableName = Config.TB_TRLHS2RHS; 
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" (";
		sql += "ATTRIBUTE_ID NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "LHS_VALUE_ID NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "LHS_GENDER NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "RHS_VALUE_ID NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "RHS_GENDER NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "RESPONSE VARCHAR2(2 BYTE), ";
		sql += "INT_COUNT NUMBER(10,0) NOT NULL ENABLE";
		sql += ")";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.insertQuery(sql);

		sql ="CREATE INDEX IDX_"+tableName+" ON "+tableName+" ('RESPONSE', 'LHS_GENDER', 'RHS_GENDER', 'ATTRIBUTE_ID', 'LHS_VALUE_ID', 'RHS_VALUE_ID')";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.insertQuery(sql); 		
	}

	
	public void createTbTrainSubgroupUser() throws SQLException {
		String tableName = Config.TB_TRSUBGROUP_USER; 
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" (";
		sql += "ATTRIBUTE_ID NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "VALUE_ID NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "GENDER NUMBER(10,0) NOT NULL ENABLE, ";
		sql += "USER_COUNT NUMBER(10,0) NOT NULL ENABLE";
		sql += ")";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.insertQuery(sql);

		sql ="CREATE INDEX IDX_"+tableName+" ON "+tableName+" ('ATTRIBUTE_ID', 'VALUE_ID')";
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.insertQuery(sql); 		
	}

	
	public void createTbTrainP2Q() throws SQLException {
		String tableName = Config.TB_TRP2Q; 
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" AS ";
		sql += "SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, RESPONSE, SUM(INT_COUNT) AS INT_COUNT FROM " + Config.TB_TRLHS2RHS + " ";
		sql += "GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, RESPONSE ";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
		sql ="CREATE INDEX IDX_"+tableName+" ON "+tableName+" ('RESPONSE', 'LHS_GENDER', 'RHS_GENDER')";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql); 		
	}
	
	public void createTbTrainP2RHS() throws SQLException {
		String tableName = Config.TB_TRP2RHS; 
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" AS ";
		sql += "SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, RHS_VALUE_ID, RESPONSE, SUM(INT_COUNT) AS INT_COUNT FROM "+Config.TB_TRLHS2RHS+" ";
		sql += "GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, RHS_VALUE_ID, RESPONSE ";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);

		sql ="CREATE INDEX IDX_"+tableName+" ON "+tableName+" ('RESPONSE', 'LHS_GENDER', 'RHS_GENDER', 'ATTRIBUTE_ID', 'RHS_VALUE_ID')";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql); 		
	}
	
	
	/**
	 * DROP TABLE PJT1_TR_SCORE_THRESHOLD PURGE;
		CREATE TABLE PJT1_TR_SCORE_THRESHOLD AS
		SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID, AVG(SCORE) AS AVG_SCORE, stddev(SCORE) AS STDDEV_SCORE, AVG(SCORE)+ stddev(SCORE)/2 AS SCORE_THRESHOLD  
		FROM PJT1_TR_LOOKUP_EXT 
		GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID
		ORDER BY ATTRIBUTE_ID;
		COMMIT;

	 * 
	 * 
	 * @throws SQLException
	 */
	public void createTbTrainScoreThreshold() throws SQLException {
		String tableName = Config.TB_TRSCORETHRESHOLD;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" AS ";
		sql += "SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID,  AVG(SCORE) AS AVG_SCORE, " +
				"stddev(SCORE) AS STDDEV_SCORE, AVG(SCORE)+ stddev(SCORE)/2 AS SCORE_THRESHOLD  FROM "+Config.TB_TRSUBGROUP_INTEREST+" ";
		sql += "GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID ";
		sql += "ORDER BY ATTRIBUTE_ID ";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
	}
	
	public void createTbTrainIMSThreshold() throws SQLException {
		String tableName = Config.TB_TRIMSTHRESHOLD;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" AS ";
		sql += "SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID,  AVG(IMS) AS AVG_SCORE, " +
				"stddev(IMS) AS STDDEV_SCORE, AVG(IMS)+ stddev(IMS)/2 AS SIMILA_ATTRIBUTE_THRESHOLD FROM "+Config.TB_TRSUBGROUP_INTEREST+" ";
		sql += "GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID ";
		sql += "ORDER BY ATTRIBUTE_ID ";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
		
	}
	
	public void createTbTrainPIMSThreshold() throws SQLException {
		String tableName = Config.TB_TRPIMSTHRESHOLD;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" AS ";
		sql += "SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID,  AVG(PIMS) AS AVG_SCORE, " +
				"stddev(PIMS) AS STDDEV_SCORE, AVG(PIMS)+ stddev(PIMS)/2 AS SIMILA_ATTRIBUTE_THRESHOLD FROM "+Config.TB_TRSUBGROUP_INTEREST+" ";
		sql += "GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID ";
		sql += "ORDER BY ATTRIBUTE_ID ";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
	}
	
	public void createTbTrainLMSThreshold() throws SQLException {
		String tableName = Config.TB_TRLMSTHRESHOLD;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" AS ";
		sql += "SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID,  AVG(LMS) AS AVG_SCORE, " +
				"stddev(LMS) AS STDDEV_SCORE, AVG(LMS)+ stddev(LMS)/2 AS SIMILA_ATTRIBUTE_THRESHOLD FROM "+Config.TB_TRSUBGROUP_INTEREST+" ";
		sql += "GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID ";
		sql += "ORDER BY ATTRIBUTE_ID ";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
	}
	
	
	public void createTbTrainPLMSThreshold() throws SQLException {
		String tableName = Config.TB_TRPLMSTHRESHOLD;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" AS ";
		sql += "SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID,  AVG(PLMS) AS AVG_SCORE, " +
				"stddev(PLMS) AS STDDEV_SCORE, AVG(PLMS)+ stddev(PLMS)/2 AS SIMILA_ATTRIBUTE_THRESHOLD FROM "+Config.TB_TRSUBGROUP_INTEREST+" ";
		sql += "GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID ";
		sql += "ORDER BY ATTRIBUTE_ID ";
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
	}

	
//	private void createTbTrainSimSubgroupSuccess(String tableName) {
//		
//		if(m_Database.isTableExist(tableName)>0)
//			m_Database.dropTable(tableName);	
//		
//		String sql = "CREATE TABLE "+tableName+" AS ";
//		sql += "SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID,  AVG(PLMS) AS AVG_SCORE, " +
//				"stddev(PLMS) AS STDDEV_SCORE, AVG(PLMS)+ stddev(PLMS)/2 AS SIMILA_ATTRIBUTE_THRESHOLD FROM "+Config.TB_TRSUBGROUP_INTEREST+" ";
//		sql += "GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID ";
//		sql += "ORDER BY ATTRIBUTE_ID ";
//		
//		
//		
//		if(Config.SQL_LOG)
//			LoggerWrapper.info("table", "SQL: " + sql );
//		m_Database.updateQuery(sql);	
//	}
	
	
	/**
	 * 
	 * 
	 * SELECT * FROM PJT1_TR_LOOKUP_EXT T WHERE  (T.SCORE>
(
  SELECT SCORE_THRESHOLD FROM PJT1_TR_SCORE_THRESHOLD S WHERE T.ATTRIBUTE_ID=S.ATTRIBUTE_ID AND T.LHS_GENDER=S.LHS_GENDER AND T.RHS_GENDER=S.RHS_GENDER AND T.LHS_VALUE_ID=S.LHS_VALUE_ID
) OR T.RANK=1)
AND T.LHS_VALUE_ID NOT IN (0, 1000000) AND  T.RHS_VALUE_ID NOT IN (0, 1000000)
ORDER BY T.ATTRIBUTE_ID,T.LHS_VALUE_ID, T.LHS_GENDER, T.RHS_GENDER ;
COMMIT;
	 * @throws SQLException
	 */
	public void createTbTrainSimSubgroup() throws SQLException {
		String tableName = Config.TB_TRSIMSUBGROUP;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" AS \n";
		sql += "SELECT * FROM "+Config.TB_TRSUBGROUP_INTEREST+" T WHERE  (T.SCORE> \n";
		sql += "( \n";
		sql += "SELECT SCORE_THRESHOLD FROM "+Config.TB_TRSCORETHRESHOLD+" S \n" +
				"WHERE T.ATTRIBUTE_ID=S.ATTRIBUTE_ID AND T.LHS_GENDER=S.LHS_GENDER AND T.RHS_GENDER=S.RHS_GENDER AND T.LHS_VALUE_ID=S.LHS_VALUE_ID \n";
		sql += ") OR T.RANK=1) \n";
		sql += " AND T.LHS_VALUE_ID NOT IN ("+Config.NOT_IMPORTANT+", "+Config.NULL_VALUE+") AND  T.RHS_VALUE_ID NOT IN ("+Config.NOT_IMPORTANT+", "+Config.NULL_VALUE+") \n";
		sql += " ORDER BY T.ATTRIBUTE_ID,T.LHS_VALUE_ID, T.LHS_GENDER, T.RHS_GENDER \n";
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql); 
	}
	
	
	
	public void createTbTrainSimSubgroup(String matchinScore) throws SQLException {
		String simSubgroupTableName ="";
		String thresholdTableName = "";
		
		if(matchinScore.equals("IMS")) {
			simSubgroupTableName = Config.TB_TRIMSSIMSUBGROUP;
			thresholdTableName = Config.TB_TRIMSTHRESHOLD;
		} else if (matchinScore.equals("PIMS")){
			simSubgroupTableName = Config.TB_TRPIMSSIMSUBGROUP;
			thresholdTableName = Config.TB_TRPIMSTHRESHOLD;
		} else if (matchinScore.equals("LMS")){
			simSubgroupTableName = Config.TB_TRLMSSIMSUBGROUP;
			thresholdTableName = Config.TB_TRLMSTHRESHOLD;
		} else if (matchinScore.equals("PLMS")){
			simSubgroupTableName = Config.TB_TRPLMSSIMSUBGROUP;
			thresholdTableName = Config.TB_TRPLMSTHRESHOLD;
		}
		
		if(m_Database.isTableExist(simSubgroupTableName)>0)
			m_Database.dropTable(simSubgroupTableName);	
		
		String sql = "CREATE TABLE "+simSubgroupTableName+" AS \n";
		sql += "SELECT * FROM "+Config.TB_TRSUBGROUP_INTEREST+" T WHERE  (T."+matchinScore+"> \n";
		sql += "( \n";
		sql += "SELECT SIMILA_ATTRIBUTE_THRESHOLD FROM "+thresholdTableName+" S \n" +
				"WHERE T.ATTRIBUTE_ID=S.ATTRIBUTE_ID AND T.LHS_GENDER=S.LHS_GENDER AND T.RHS_GENDER=S.RHS_GENDER AND T.LHS_VALUE_ID=S.LHS_VALUE_ID \n";
		sql += ")) \n";
		sql += " AND T.LHS_VALUE_ID NOT IN ("+Config.NOT_IMPORTANT+", "+Config.NULL_VALUE+") AND  T.RHS_VALUE_ID NOT IN ("+Config.NOT_IMPORTANT+", "+Config.NULL_VALUE+") \n";
		sql += " ORDER BY T.ATTRIBUTE_ID,T.LHS_VALUE_ID, T.LHS_GENDER, T.RHS_GENDER \n";
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql); 
	}
	
	public void createTbTrainMertic(){
		String tableName = Config.TB_TRMETRIC;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);
		
		String sql = "CREATE TABLE "+tableName+" AS \n";
		sql += "SELECT L.*,  \n";		
		sql += "ROUND(L.LHS2RHS/LHS2Q, 6) AS ABSOLUTE_INTEREST, \n";
		sql += "ROUND(L.RHS_USERS/L.Q_USERS, 6) AS EXPECTED_INTEREST, \n";
		sql += "ROUND((L.LHS2RHS/L.LHS2Q)/(L.RHS_USERS/L.Q_USERS), 6) AS RELATIVE_INTEREST, \n";
		sql += "ROUND(L.P2RHS/L.P2Q, 6) AS GENERAL_INTEREST, \n";
		sql += "ROUND((L.LHS2RHS/L.LHS2Q)/(L.P2RHS/L.P2Q), 6) AS COMPARATIVE_INTEREST, \n";

		//-- RHS's interest in LHS
		sql += "ROUND(L.LHS2RHS_T/L.LHS2RHS, 6) AS ABSOLUTE_POSITIVE, \n";
		sql += "ROUND(L.P2RHS_T/P2RHS, 6) AS EXPECTED_POSITIVE, \n";
		sql += "ROUND((L.LHS2RHS_T/L.LHS2RHS)/(L.P2RHS_T/P2RHS), 6) AS RELATIVE_POSITIVE, \n";
		sql += "ROUND(L.LHS2Q_T/L.LHS2Q, 6) AS GENDERAL_POSITIVE, \n";
		sql += "ROUND((L.LHS2RHS_T/L.LHS2RHS)/(L.LHS2Q_T/L.LHS2Q), 6) AS COMPARATIVE_POSITIVE \n";
		sql += "FROM "+Config.TB_TRLOOKUP+" L \n";
		sql += "WHERE L.RHS_USERS>0 AND L.LHS2Q_T>0 AND L.P2RHS>0 AND L.Q2LHS>0 AND L.P2RHS_T>0 \n";
		
		if(Config.SQL_LOG) LoggerWrapper.info("table", "SQL: " + sql );
		
		try {
			m_Database.insertQuery(sql);
			sql ="CREATE INDEX IDX_"+tableName+" ON "+tableName+" ('ATTRIBUTE_ID', 'LHS_VALUE_ID', 'LHS_GENDER', 'RHS_VALUE_ID', 'RHS_GENDER')";
			if(Config.SQL_LOG) LoggerWrapper.info("table", "SQL: " + sql );
			m_Database.insertQuery(sql);	
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
//	public void createTbTrainLookUpExt() throws SQLException {
//		String tableName = Config.TB_TRSUBGROUP_INTEREST;
//		
//		if(m_Database.isTableExist(tableName)>0)
//			m_Database.dropTable(tableName);	
//		
//		String sql = "CREATE TABLE "+tableName+" AS \n";
//		sql += "SELECT TB3.*,  \n";
//		
//		
//		sql += "2/((1/TB3.SND_INTEREST)+(1/TB3.RCV_INTEREST)) AS IMS, \n";
//		sql += "2/((1/TB3.SND_SUCCESS)+(1/TB3.RCV_SUCCESS)) AS PIMS, \n";
//		sql += "2/((1/(TB3.SND_INTEREST/TB3.GSND_INTEREST))+(1/(TB3.RCV_INTEREST/TB3.GRCV_INTEREST))) AS  LMS, \n";
//		sql += "2/((1/(TB3.SND_SUCCESS/TB3.GSND_SUCCESS))+(1/(TB3.RCV_SUCCESS/TB3.GRCV_SUCCESS))) AS PLMS \n";
//		sql += "FROM \n";
//		sql += "( \n";
//		sql += "  SELECT TB2.*, \n";
//		//Sender interest LHS2RHS/LHS2ALL
//		sql += "  (TB2.LHS2RHS_F+TB2.LHS2RHS_T)/(TB2.LHS2Q_F+TB2.LHS2Q_T) AS SND_INTEREST, \n";
//		
//		//Receiver  interest RHS2LHS/RHS2ALL
//		sql += "  (TB2.RHS2LHS_F+TB2.RHS2LHS_T)/(TB2.RHS2P_F+TB2.RHS2P_T) AS RCV_INTEREST, \n";
//		
//		//Receiver's interest in LHS by success 
//		sql += "  TB2.LHS2RHS_T/(TB2.LHS2RHS_F+TB2.LHS2RHS_T) AS SND_SUCCESS, \n";
//		// Sender's interest by success
//		sql += "  TB2.RHS2LHS_T/(TB2.RHS2LHS_F+TB2.RHS2LHS_T) AS RCV_SUCCESS, \n";
//		
//		//General sender interest
//		sql += "  (TB2.P2RHS_F+TB2.P2RHS_T)/(TB2.P2Q_F+TB2.P2Q_T) AS GSND_INTEREST, \n";
//		
//		//General receiver interest
//		sql += "  (TB2.Q2LHS_F+TB2.Q2LHS_T)/(TB2.Q2P_F+TB2.Q2P_T) AS GRCV_INTEREST, \n";
//		
//		//Receiver's interest in general senders
//		sql += "  TB2.P2RHS_T/(TB2.P2RHS_F+TB2.P2RHS_T) AS GSND_SUCCESS, \n";
//		
//		//Sender's interest in general receivers
//		sql += "  TB2.Q2LHS_T/(TB2.Q2LHS_F+TB2.Q2LHS_T) AS GRCV_SUCCESS \n";
//		//# of sender
//		sql += "  (SELECT USER_COUNT FROM "+Config.TB_TRSUBGROUP_USER+" WHERE ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND VALUE_ID=TB2.LHS_VALUE_ID AND GENDER=TB2.LHS_GENDER) AS SND_COUNT \n";
//		// # of receivers
//		sql += "  (SELECT USER_COUNT FROM "+Config.TB_TRSUBGROUP_USER+" WHERE ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND VALUE_ID=TB2.RHS_VALUE_ID AND GENDER=TB2.RHS_GENDER) AS SND_COUNT \n";
//		
//		
//		
//		sql += "  FROM \n";
//		sql += "  ( \n";
//		sql += "    SELECT TB1.*, \n"; 
//		sql += "    (SELECT SUM(LHS2RHS_F) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.LHS_VALUE_ID=TB2.LHS_VALUE_ID AND TB1.LHS_GENDER=TB2.LHS_GENDER AND TB1.RHS_GENDER=TB2.RHS_GENDER) AS LHS2Q_F, \n";
//		sql += "    (SELECT SUM(LHS2RHS_T) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.LHS_VALUE_ID=TB2.LHS_VALUE_ID AND TB1.LHS_GENDER=TB2.LHS_GENDER AND TB1.RHS_GENDER=TB2.RHS_GENDER) AS LHS2Q_T, \n";
//		sql += "    (SELECT SUM(LHS2RHS_F) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.RHS_VALUE_ID=TB2.RHS_VALUE_ID AND TB1.LHS_GENDER=TB2.LHS_GENDER AND TB1.RHS_GENDER=TB2.RHS_GENDER) AS P2RHS_F, \n";
//		sql += "    (SELECT SUM(LHS2RHS_T) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.RHS_VALUE_ID=TB2.RHS_VALUE_ID AND TB1.LHS_GENDER=TB2.LHS_GENDER AND TB1.RHS_GENDER=TB2.RHS_GENDER) AS P2RHS_T, \n";
//		sql += "    (SELECT SUM(LHS2RHS_F) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.LHS_GENDER=TB2.LHS_GENDER AND TB1.RHS_GENDER=TB2.RHS_GENDER) AS P2Q_F, \n";
//		sql += "    (SELECT SUM(LHS2RHS_T) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.LHS_GENDER=TB2.LHS_GENDER AND TB1.RHS_GENDER=TB2.RHS_GENDER) AS P2Q_T, \n";
//		sql += "    (SELECT SUM(LHS2RHS_F) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.RHS_VALUE_ID=TB2.LHS_VALUE_ID AND TB1.RHS_GENDER=TB2.LHS_GENDER AND TB1.LHS_GENDER=TB2.RHS_GENDER) AS RHS2P_F, \n";
//		sql += "    (SELECT SUM(LHS2RHS_T) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.RHS_VALUE_ID=TB2.LHS_VALUE_ID AND TB1.RHS_GENDER=TB2.LHS_GENDER AND TB1.LHS_GENDER=TB2.RHS_GENDER) AS RHS2P_T, \n";
//		sql += "    (SELECT SUM(LHS2RHS_F) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.LHS_VALUE_ID=TB2.RHS_VALUE_ID AND TB1.RHS_GENDER=TB2.LHS_GENDER AND TB1.LHS_GENDER=TB2.RHS_GENDER) AS Q2LHS_F, \n";
//		sql += "    (SELECT SUM(LHS2RHS_T) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.LHS_VALUE_ID=TB2.RHS_VALUE_ID AND TB1.RHS_GENDER=TB2.LHS_GENDER AND TB1.LHS_GENDER=TB2.RHS_GENDER) AS Q2LHS_T, \n";
//		sql += "    (SELECT SUM(LHS2RHS_F) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.RHS_GENDER=TB2.LHS_GENDER AND TB1.LHS_GENDER=TB2.RHS_GENDER) AS Q2P_F, \n";
//		sql += "    (SELECT SUM(LHS2RHS_T) FROM "+Config.TB_TRLOOKUP+" TB2 WHERE TB1.ATTRIBUTE_ID=TB2.ATTRIBUTE_ID AND TB1.RHS_GENDER=TB2.LHS_GENDER AND TB1.LHS_GENDER=TB2.RHS_GENDER) AS Q2P_T \n";
//		sql += "    FROM \n";
//		sql += "    "+Config.TB_TRLOOKUP+" TB1 \n"; 
//		sql += "  ) TB2 \n";
//		sql += ") TB3  \n";
//		sql += "WHERE SND_INTEREST>0 AND RCV_INTEREST>0 AND SND_SUCCESS>0 AND RCV_SUCCESS>0 AND GSND_INTEREST>0 AND GRCV_INTEREST>0 AND GSND_SUCCESS>0 AND GRCV_SUCCESS>0  \n";
//
//		if(Config.SQL_LOG) LoggerWrapper.info("table", "SQL: " + sql );
//		
//		m_Database.insertQuery(sql);
//
//		sql ="CREATE INDEX IDX_"+tableName+" ON "+tableName+" ('ATTRIBUTE_ID', 'LHS_VALUE_ID', 'LHS_GENDER', 'RHS_VALUE_ID', 'RHS_GENDER')";
//		
//		if(Config.SQL_LOG) LoggerWrapper.info("table", "SQL: " + sql );
//		
//		m_Database.insertQuery(sql); 
////		System.exit(0);
//	}
	
	/**
	 * DROP TABLE PJT1_TR_SCORE_THRESHOLD PURGE;
		CREATE TABLE PJT1_TR_SCORE_THRESHOLD AS
		SELECT ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID, AVG(SCORE) AS AVG_SCORE, stddev(SCORE) AS STDDEV_SCORE, AVG(SCORE)+ stddev(SCORE)/2 AS SCORE_THRESHOLD  
		FROM PJT1_TR_LOOKUP_EXT 
		GROUP BY ATTRIBUTE_ID, LHS_GENDER, RHS_GENDER, LHS_VALUE_ID
		ORDER BY ATTRIBUTE_ID;
		COMMIT;

	 * 
	 * 
	 * @throws SQLException
	 */
	public void createTbTrainSuccessRate() throws SQLException {
		String tableName = Config.TB_TRSUCESS_RATE;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName+" AS ";
		sql += "SELECT 134 AS SND, 135 AS RCV, A_KISS_COUNT, P_KISS_COUNT, P_KISS_COUNT/A_KISS_COUNT AS SUCCESS_RATE FROM ";
		sql += "(SELECT COUNT(*) AS A_KISS_COUNT FROM "+Config.TB_TRKISS_LOG+" KS, "+Config.TB_TRUSER+" SND, "+Config.TB_TRUSER+" RCV ";
		sql += "WHERE KS.INITIATINGUSERID=SND.USERID AND KS.TARGETUSERID=RCV.USERID ";
		sql += "AND SND.GENDER_PRID=134 AND RCV.GENDER_PRID=135), ";
		sql += "(SELECT COUNT(*) AS P_KISS_COUNT FROM "+Config.TB_TRKISS_LOG+" KS, "+Config.TB_TRUSER+" SND, "+Config.TB_TRUSER+" RCV ";
		sql += "WHERE KS.INITIATINGUSERID=SND.USERID AND KS.TARGETUSERID=RCV.USERID AND RESPONSE='P' ";
		sql += "AND SND.GENDER_PRID=134 AND RCV.GENDER_PRID=135) ";
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
		
		sql = "INSERT INTO "+tableName+"  ";
		sql += "SELECT 135 AS SND, 134 AS RCV, A_KISS_COUNT, P_KISS_COUNT, P_KISS_COUNT/A_KISS_COUNT AS SUCCESS_RATE FROM ";
		sql += "(SELECT COUNT(*) AS A_KISS_COUNT FROM "+Config.TB_TRKISS_LOG+" KS, "+Config.TB_TRUSER+" SND, "+Config.TB_TRUSER+" RCV ";
		sql += "WHERE KS.INITIATINGUSERID=SND.USERID AND KS.TARGETUSERID=RCV.USERID ";
		sql += "AND SND.GENDER_PRID=135 AND RCV.GENDER_PRID=134), ";
		sql += "(SELECT COUNT(*) AS P_KISS_COUNT FROM "+Config.TB_TRKISS_LOG+" KS, "+Config.TB_TRUSER+" SND, "+Config.TB_TRUSER+" RCV ";
		sql += "WHERE KS.INITIATINGUSERID=SND.USERID AND KS.TARGETUSERID=RCV.USERID AND RESPONSE='P' ";
		sql += "AND SND.GENDER_PRID=135 AND RCV.GENDER_PRID=134) ";
		
		if(Config.SQL_LOG)
			LoggerWrapper.info("table", "SQL: " + sql );
		m_Database.updateQuery(sql);
	}
	
	public void createTbKissUser() throws SQLException {
		String tableName = Config.TB_TRKISSUSER;
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);
		
		String sql ="CREATE TABLE "+Config.TB_TRKISSUSER+ " AS  "; 
		sql +="SELECT ";
		sql +="S.USERID AS S_USERID, ";
		sql +="S.AGE_BIN AS S_AGE_BIN, ";
		sql +="S.CHIRDREN_BIN AS S_CHIRDREN_BIN, ";
		sql +="S.HHASPHOTO AS S_HHASPHOTO, ";
		sql +="S.HHASSECONDARYPHOTO AS S_HHASSECONDARYPHOTO, ";
		sql +="S.SEEKINGPENPAL AS S_SEEKINGPENPAL, ";
		sql +="S.SEEKINGFRIEND AS S_SEEKINGFRIEND, ";
		sql +="S.SEEKINGRELSHORT AS S_SEEKINGRELSHORT, ";
		sql +="S.SEEKINGRELLONG AS S_SEEKINGRELLONG, ";
		sql +="S.HAVEPETS AS S_HAVEPETS, ";
		sql +="S.OCC_INDUSTRY_PRID AS S_OCC_INDUSTRY_PRID, ";
		sql +="S.OCC_LEVEL_PRID AS S_OCC_LEVEL_PRID, ";
		sql +="S.STARSIGN_PRID AS S_STARSIGN_PRID, ";
		sql +="S.HAIRCOLOR_PRID AS S_HAIRCOLOR_PRID, ";
		sql +="S.EYECOLOR_PRID AS S_EYECOLOR_PRID, ";
		sql +="S.MARITAL_STATUS_PRID AS S_MARITAL_STATUS_PRID, ";
		sql +="S.BODYTYPE_PRID AS S_BODYTYPE_PRID, ";
		sql +="S.SEXUALITY_PRID AS S_SEXUALITY_PRID, ";
		sql +="S.GENDER_PRID AS S_GENDER_PRID, ";
		sql +="S.NATIONALITY_PRID AS S_NATIONALITY_PRID, ";
		sql +="S.ETHNICBACKGROUND_PRID AS S_ETHNICBACKGROUND_PRID, ";
		sql +="S.RELIGION_PRID AS S_RELIGION_PRID, ";
		sql +="S.PERSONALITY_PRID AS S_PERSONALITY_PRID, ";
		sql +="S.WANTCHILDREN_PRID AS S_WANTCHILDREN_PRID, ";
		sql +="S.EDUCATION_PRID AS S_EDUCATION_PRID, ";
		sql +="S.HAVECHILDREN_PRID AS S_HAVECHILDREN_PRID, ";
		sql +="S.SMOKE_PRID AS S_SMOKE_PRID, ";
		sql +="S.POLITICS_PRID AS S_POLITICS_PRID, ";
		sql +="S.DIET_PRID AS S_DIET_PRID, ";
		sql +="S.HEIGHT_PRID AS S_HEIGHT_PRID, ";
		sql +="S.DRINK_PRID AS S_DRINK_PRID, ";
		sql +="S.PLATONIC_GENDER_SOUGHT_PRID AS S_PLATONIC_GENDER_SOUGHT_PRID, ";
		sql +="S.LOC_REGIONID AS S_LOC_REGIONID, ";
		sql +="S.LOC_COUNTRYID AS S_LOC_COUNTRYID, ";
		sql +="S.LOC_DIVISIONID AS S_LOC_DIVISIONID, ";
		sql +="S.LOC_LOCUSPOINTID AS S_LOC_LOCUSPOINTID, ";
		sql +="S.HDATEOFBIRTH AS S_HDATEOFBIRTH, ";
		sql +="S.CREATIONDATE AS S_CREATIONDATE, ";
		sql +="S.LASTUPDATE AS S_LASTUPDATE, ";
		sql +="S.LOC_LATITUDE AS S_LOC_LATITUDE, ";
		sql +="S.LOC_LONGITUDE AS S_LOC_LONGITUDE, ";
		sql +="R.USERID AS R_USERID, ";
		sql +="R.AGE_BIN AS R_AGE_BIN, ";
		sql +="R.CHIRDREN_BIN AS R_CHIRDREN_BIN, ";
		sql +="R.HHASPHOTO AS R_HHASPHOTO, ";
		sql +="R.HHASSECONDARYPHOTO AS R_HHASSECONDARYPHOTO, ";
		sql +="R.SEEKINGPENPAL AS R_SEEKINGPENPAL, ";
		sql +="R.SEEKINGFRIEND AS R_SEEKINGFRIEND, ";
		sql +="R.SEEKINGRELSHORT AS R_SEEKINGRELSHORT, ";
		sql +="R.SEEKINGRELLONG AS R_SEEKINGRELLONG, ";
		sql +="R.HAVEPETS AS R_HAVEPETS, ";
		sql +="R.OCC_INDUSTRY_PRID AS R_OCC_INDUSTRY_PRID, ";
		sql +="R.OCC_LEVEL_PRID AS R_OCC_LEVEL_PRID, ";
		sql +="R.STARSIGN_PRID AS R_STARSIGN_PRID, ";
		sql +="R.HAIRCOLOR_PRID AS R_HAIRCOLOR_PRID, ";
		sql +="R.EYECOLOR_PRID AS R_EYECOLOR_PRID, ";
		sql +="R.MARITAL_STATUS_PRID AS R_MARITAL_STATUS_PRID, ";
		sql +="R.BODYTYPE_PRID AS R_BODYTYPE_PRID, ";
		sql +="R.SEXUALITY_PRID AS R_SEXUALITY_PRID, ";
		sql +="R.GENDER_PRID AS R_GENDER_PRID, ";
		sql +="R.NATIONALITY_PRID AS R_NATIONALITY_PRID, ";
		sql +="R.ETHNICBACKGROUND_PRID AS R_ETHNICBACKGROUND_PRID, ";
		sql +="R.RELIGION_PRID AS R_RELIGION_PRID, ";
		sql +="R.PERSONALITY_PRID AS R_PERSONALITY_PRID, ";
		sql +="R.WANTCHILDREN_PRID AS R_WANTCHILDREN_PRID, ";
		sql +="R.EDUCATION_PRID AS R_EDUCATION_PRID, ";
		sql +="R.HAVECHILDREN_PRID AS R_HAVECHILDREN_PRID, ";
		sql +="R.SMOKE_PRID AS R_SMOKE_PRID, ";
		sql +="R.POLITICS_PRID AS R_POLITICS_PRID, ";
		sql +="R.DIET_PRID AS R_DIET_PRID, ";
		sql +="R.HEIGHT_PRID AS R_HEIGHT_PRID, ";
		sql +="R.DRINK_PRID AS R_DRINK_PRID, ";
		sql +="R.PLATONIC_GENDER_SOUGHT_PRID AS R_PLATONIC_GENDER_SOUGHT_PRID, ";
		sql +="R.LOC_REGIONID AS R_LOC_REGIONID, ";
		sql +="R.LOC_COUNTRYID AS R_LOC_COUNTRYID, ";
		sql +="R.LOC_DIVISIONID AS R_LOC_DIVISIONID, ";
		sql +="R.LOC_LOCUSPOINTID AS R_LOC_LOCUSPOINTID, ";
		sql +="R.HDATEOFBIRTH AS R_HDATEOFBIRTH, ";
		sql +="R.CREATIONDATE AS R_CREATIONDATE, ";
		sql +="R.LASTUPDATE AS R_LASTUPDATE, ";
		sql +="R.LOC_LATITUDE AS R_LOC_LATITUDE, ";
		sql +="R.LOC_LONGITUDE AS R_LOC_LONGITUDE, ";
		sql +="LO.response ";
		sql +="FROM "+Config.TB_TRKISS_LOG+" lo,  "+Config.TB_TRUSER+" S, "+Config.TB_TRUSER+" R ";
		sql +="WHERE lo.INITIATINGUSERID=S.USERID AND lo.TARGETUSERID=R.USERID"; 	
		
		
		if(Config.SQL_LOG) LoggerWrapper.info("train", "Query: " + sql);
		this.m_Database.updateQuery(sql);
		
		sql = "CREATE INDEX IDX_"+Config.TB_TRKISSUSER+" ON "+Config.TB_TRKISSUSER+" "; 
		sql += "( ";
				sql += "'S_AGE_BIN', ";
				sql += "'S_BODYTYPE_PRID',";
				sql += "'S_EDUCATION_PRID',";
				sql += "'S_ETHNICBACKGROUND_PRID',";
				sql += "'S_EYECOLOR_PRID',";
				sql += "'S_HAIRCOLOR_PRID',";
				sql += "'S_HEIGHT_PRID',";
				sql += "'S_OCC_INDUSTRY_PRID',";
				sql += "'S_OCC_LEVEL_PRID',";
				sql += "'S_LOC_LOCUSPOINTID',";
				sql += "'S_RELIGION_PRID',";
				sql += "'R_AGE_BIN',";
				sql += "'R_BODYTYPE_PRID',";
				sql += "'R_EDUCATION_PRID',";
				sql += "'R_ETHNICBACKGROUND_PRID',";
				sql += "'R_EYECOLOR_PRID',";
				sql += "'R_HAIRCOLOR_PRID',";
				sql += "'R_HEIGHT_PRID',";
				sql += "'R_OCC_INDUSTRY_PRID',";
				sql += "'R_OCC_LEVEL_PRID',";
				sql += "'R_LOC_LOCUSPOINTID',";
				sql += "'R_MARITAL_STATUS_PRID',";
				sql += "'R_RELIGION_PRID'";
				sql += ")";
				
		if(Config.SQL_LOG) LoggerWrapper.info("train", "Query: " + sql);
		this.m_Database.updateQuery(sql);	
		
	}
	
	
	
	
	public ArrayList<Integer> getLocuspointId() throws SQLException{
		ArrayList<Integer> locusPointIds = new ArrayList<Integer>();
		
		String sql = "SELECT DISTINCT LOC_LOCUSPOINTID FROM  "+Config.TB_TRUSER+" WHERE LOC_LOCUSPOINTID<51 ORDER BY LOC_LOCUSPOINTID ASC"; 
		
		if(Config.SQL_LOG) LoggerWrapper.info("train", "Query: " + sql);	
		PreparedStatement ps = null;
		ResultSet rs = null;	
		try {
			ps = m_Connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				locusPointIds.add( rs.getInt(1));
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}finally {
			if(ps!=null)
				ps.close();
			if(rs!=null)
				rs.close();			
		}
		
		return locusPointIds;
	}
	
	public ArrayList<Integer> getAgeBinId() throws SQLException{
		ArrayList<Integer> ageBinIds = new ArrayList<Integer>();
		
		String sql = "SELECT DISTINCT AGE_BIN FROM  "+Config.TB_TRUSER+" ORDER BY AGE_BIN ASC"; 
		
		if(Config.SQL_LOG) LoggerWrapper.info("train", "Query: " + sql);	
		PreparedStatement ps = null;
		ResultSet rs = null;	
		try {
			ps = m_Connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()){
				ageBinIds.add( rs.getInt(1));
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}finally {
			if(ps!=null)
				ps.close();
			if(rs!=null)
				rs.close();			
		}
		
		return ageBinIds;
	}
	
	
	
	private void createTbSub(String tableSuffix, int sndGenderId, int locuspointId) throws SQLException {
		
		if(m_Database.isTableExist(Config.TB_TRKISSUSER+tableSuffix)>0)
			m_Database.dropTable(Config.TB_TRKISSUSER+tableSuffix);
		
		String sql = "CREATE TABLE "+Config.TB_TRKISSUSER+tableSuffix +" AS ";     
		sql += "SELECT * FROM "+Config.TB_TRKISSUSER +" WHERE S_GENDER_PRID="+sndGenderId+" AND S_LOC_LOCUSPOINTID="+locuspointId; 
		
		if(Config.SQL_LOG) 
			LoggerWrapper.info("train", "Query: " + sql);
		this.m_Database.updateQuery(sql);
		
		
		sql = "CREATE INDEX IDX_"+Config.TB_TRKISSUSER+tableSuffix+" ON "+Config.TB_TRKISSUSER+tableSuffix+" "; 
		sql += "( ";
				sql += "'S_AGE_BIN', ";
				sql += "'S_BODYTYPE_PRID',";
				sql += "'S_EDUCATION_PRID',";
				sql += "'S_ETHNICBACKGROUND_PRID',";
				sql += "'S_EYECOLOR_PRID',";
				sql += "'S_HAIRCOLOR_PRID',";
				sql += "'S_HEIGHT_PRID',";
				sql += "'S_OCC_INDUSTRY_PRID',";
				sql += "'S_OCC_LEVEL_PRID',";
				sql += "'S_LOC_LOCUSPOINTID',";
				sql += "'S_RELIGION_PRID',";
				sql += "'R_AGE_BIN',";
				sql += "'R_BODYTYPE_PRID',";
				sql += "'R_EDUCATION_PRID',";
				sql += "'R_ETHNICBACKGROUND_PRID',";
				sql += "'R_EYECOLOR_PRID',";
				sql += "'R_HAIRCOLOR_PRID',";
				sql += "'R_HEIGHT_PRID',";
				sql += "'R_OCC_INDUSTRY_PRID',";
				sql += "'R_OCC_LEVEL_PRID',";
				sql += "'R_LOC_LOCUSPOINTID',";
				sql += "'R_MARITAL_STATUS_PRID',";
				sql += "'R_RELIGION_PRID'";
				sql += ")";
				
		if(Config.SQL_LOG) 
			LoggerWrapper.info("train", "Query: " + sql);
		this.m_Database.updateQuery(sql);	
//		System.exit(0);
	}
	
	public void createTbSubRegionKisses() throws SQLException {
		ArrayList<Integer> genderId = new ArrayList<Integer>();
		genderId.add(134);
		genderId.add(135);
		ArrayList<Integer> locusPointIds = this.getLocuspointId();
		
		for(int i=0; i<genderId.size(); i++) {
			for(int j=0; j<locusPointIds.size(); j++) {
				this.createTbSub(genderId.get(i)+"_"+locusPointIds.get(j), genderId.get(i), locusPointIds.get(j));
			}
		}
	}
	
	

	
	/**
	 * Create subset of kisses by age bin
	 *  
	 * @throws SQLException
	 */
	public void createTbSubsetOfKissesByAgeBin() throws SQLException {
		ArrayList<Integer> genderId = new ArrayList<Integer>();
		genderId.add(134);
		genderId.add(135);
		
		ArrayList<Integer> ageBinIds = this.getAgeBinId();
		
		for(int i=0; i<genderId.size(); i++) {
			for(int j=0; j<ageBinIds.size(); j++) {
				this.createTbSubsetOfKissesByAgeBin(genderId.get(i)+"_"+ageBinIds.get(j), genderId.get(i), ageBinIds.get(j));
			}
		}
	}
	
	
	private void createTbSubsetOfKissesByAgeBin(String tableSuffix, int sndGenderId, int ageBinId) throws SQLException {
		String tableName = Config.TB_TRSUBSETKISSES+tableSuffix;
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);
		
		String sql = "CREATE TABLE "+tableName +" AS ";     
		sql += "SELECT * FROM "+Config.TB_TRKISSUSER +" WHERE S_GENDER_PRID="+sndGenderId+" AND S_AGE_BIN="+ageBinId; 
		
		if(Config.SQL_LOG) 
			LoggerWrapper.info("train", "Query: " + sql);
		this.m_Database.updateQuery(sql);
		
		
		sql = "CREATE INDEX IDX_"+tableName+" ON "+tableName+" "; 
		sql += "( ";
				sql += "'S_AGE_BIN', ";
				sql += "'S_BODYTYPE_PRID',";
				sql += "'S_EDUCATION_PRID',";
				sql += "'S_ETHNICBACKGROUND_PRID',";
				sql += "'S_EYECOLOR_PRID',";
				sql += "'S_HAIRCOLOR_PRID',";
				sql += "'S_HEIGHT_PRID',";
				sql += "'S_OCC_INDUSTRY_PRID',";
				sql += "'S_OCC_LEVEL_PRID',";
				sql += "'S_LOC_LOCUSPOINTID',";
				sql += "'S_RELIGION_PRID',";
				sql += "'R_AGE_BIN',";
				sql += "'R_BODYTYPE_PRID',";
				sql += "'R_EDUCATION_PRID',";
				sql += "'R_ETHNICBACKGROUND_PRID',";
				sql += "'R_EYECOLOR_PRID',";
				sql += "'R_HAIRCOLOR_PRID',";
				sql += "'R_HEIGHT_PRID',";
				sql += "'R_OCC_INDUSTRY_PRID',";
				sql += "'R_OCC_LEVEL_PRID',";
				sql += "'R_LOC_LOCUSPOINTID',";
				sql += "'R_MARITAL_STATUS_PRID',";
				sql += "'R_RELIGION_PRID'";
				sql += ")";
				
		if(Config.SQL_LOG) 
			LoggerWrapper.info("train", "Query: " + sql);
		this.m_Database.updateQuery(sql);	
//		System.exit(0);
	}
	
	public void createTbBestMatchingAttribute(String tableSuffix) {
		
		String tableName = Config.TB_TRBESTMATCH+tableSuffix;
		
		
		String simSubgroupTable = "";
		if(tableSuffix.equals("IMS")){
			simSubgroupTable = Config.TB_TRIMSSIMSUBGROUP;
		} else if(tableSuffix.equals("PIMS")) {
			simSubgroupTable = Config.TB_TRPIMSSIMSUBGROUP;
		} else if(tableSuffix.equals("LMS")) {
			simSubgroupTable = Config.TB_TRLMSSIMSUBGROUP;
		} else if(tableSuffix.equals("PLMS")) {
			simSubgroupTable = Config.TB_TRPLMSSIMSUBGROUP;
		}
		
		if(m_Database.isTableExist(tableName)>0)
			m_Database.dropTable(tableName);	
		
		String sql = "CREATE TABLE "+tableName +" AS \n";  
		sql += "SELECT TB3.ATTRIBUTE_ID, TB3.LHS_VALUE_ID, TB3.LHS_GENDER, TB3.RHS_GENDER, TB3.RHS_VALUE_ID, TB3.LHS2RHS_T, TB3. LHS2RHS_F, TB3.SUCCESS_RATE \n";
		sql += "FROM \n";
		sql += "( \n";
		sql += "  SELECT TB2.ATTRIBUTE_ID,TB2.LHS_VALUE_ID,TB2.LHS_GENDER, TB2.RHS_GENDER, TB2.RHS_VALUE_ID, \n"; 
		sql += "  ( \n";
		sql += "    SELECT SUM(LHS2RHS_T) \n";  
		sql += "    FROM "+simSubgroupTable+" TB3 WHERE TB2.ATTRIBUTE_ID=TB3.ATTRIBUTE_ID AND TB2.LHS_VALUE_ID = TB3.LHS_VALUE_ID AND TB2.LHS_GENDER=TB3.LHS_GENDER AND TB2.RHS_GENDER= TB3.RHS_GENDER \n";
		sql += "  ) AS LHS2RHS_T,  \n";
		sql += "  ( \n";
		sql += "    SELECT SUM(LHS2RHS_F) \n";  
		sql += "    FROM "+simSubgroupTable+" TB3 WHERE TB2.ATTRIBUTE_ID=TB3.ATTRIBUTE_ID AND TB2.LHS_VALUE_ID = TB3.LHS_VALUE_ID AND TB2.LHS_GENDER=TB3.LHS_GENDER AND TB2.RHS_GENDER= TB3.RHS_GENDER \n";
		sql += "  ) AS LHS2RHS_F,  \n";
		sql += "  ( \n";
		sql += "    SELECT SUM(LHS2RHS_T)/(SUM(LHS2RHS_T)+SUM(LHS2RHS_F)) \n";  
		sql += "    FROM "+simSubgroupTable+" TB3 WHERE TB2.ATTRIBUTE_ID=TB3.ATTRIBUTE_ID AND TB2.LHS_VALUE_ID = TB3.LHS_VALUE_ID AND TB2.LHS_GENDER=TB3.LHS_GENDER AND TB2.RHS_GENDER= TB3.RHS_GENDER \n";
		sql += "  ) AS SUCCESS_RATE \n";
		sql += "  FROM \n";
		sql += "  ( \n";
		sql += "    SELECT TB1.ATTRIBUTE_ID,TB1.LHS_VALUE_ID,TB1.LHS_GENDER, TB1.RHS_GENDER, TB1.RHS_VALUE_ID, \n";
		sql += "    ROW_NUMBER() OVER (PARTITION BY TB1.ATTRIBUTE_ID,TB1.LHS_VALUE_ID,TB1.LHS_GENDER,TB1.RHS_GENDER ORDER BY "+tableSuffix+" DESC) AS RANK \n";
		sql += "    FROM "+Config.TB_TRSUBGROUP_INTEREST+" TB1 \n";
		sql += "  ) TB2 \n";
		sql += "  WHERE TB2.RANK=1 \n";
		sql += ") TB3 WHERE TB3.SUCCESS_RATE IS NOT NULL \n";
		
		if(Config.SQL_LOG) 
			LoggerWrapper.info("train", "Query: " + sql);
		this.m_Database.updateQuery(sql);
	}
	
	
}
