package com.rsvp.rules.main;
/**
 * This class initialize train data
 * 
 * This program has been developed for CRC smart services project.
 * 
 * @author <A HREF="mailto:ykim@cse.unsw.edu.au">Yang Sok Kim</A>
 * @version $Revision: 1.1.1.1 $ $Date: 2010/10/08 15:15:25 $
 * @see [String]
 * @see [URL]
 * @see [Class name#method name]
 */

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.rsvp.config.Config;

import com.rsvp.db.ConnPool;
import com.rsvp.db.ConnPoolFactory;
import com.rsvp.db.ConnPoolProperty;
import com.rsvp.db.Database;
import com.rsvp.log.LoggerWrapper;
import com.rsvp.rules.core.Attribute;
import com.rsvp.rules.dataset.PreprocessorDataSet;

public class Preprocessor {
	public String TRAIN_START_DATE;
	public String TRAIN_END_DATE;

	public Preprocessor(String trainStartDate, String trainEndDate) {
		TRAIN_START_DATE = trainStartDate;
		TRAIN_END_DATE = trainEndDate;
	}
	
	public void initialize() throws SQLException {
		
		ConnPoolProperty connProperty = new ConnPoolProperty();
		connProperty.setUrl(Config.URL);
		connProperty.setDriverClass(Config.DRIVER);
		connProperty.setUser(Config.DBUSER);
		connProperty.setPassword(Config.DBPASS);
		connProperty.setMaxWaitMillis(Config.WIAT);
		connProperty.setInitSize(Config.MIN_POOL); 
		connProperty.setMaxSize(Config.MAX_POOL); 

		ConnPool connPool = ConnPoolFactory.getConnectionPool(connProperty);		
		Connection conn = null;

		try{
			LoggerWrapper.info("Train Manager","'-------------- START TRAIN DATA GENERATION PROCESS -----------------'");
			conn = connPool.getConnection();
			PreprocessorDataSet m_DataSet 			= new PreprocessorDataSet(conn, TRAIN_START_DATE, TRAIN_END_DATE);
			
			Database m_Database						= new Database(conn);
			
			
			/**
			 * Generate property table
			 * 5 seconds
			 */
			if(m_Database.isTableExist(Config.TB_TRPROPERTY)==0){
				m_DataSet.createTbTrainProperty();
			}
			
			
			m_DataSet.generatePropertyTable();
			LoggerWrapper.info("Train Manager","Property table is created.");
			
			
			/**
			 * Generate interaction logs
			 * 144 seconds for 5638625 kisses
			 */
			m_DataSet.createTbTrainKissLog();
			LoggerWrapper.info("Train Manager","Train kiss table is created.");

			/**
			 * Generate user profiles
			 * 118 seconds for 217916 users
			 */
			m_DataSet.createTbTrainUserProfile();
			LoggerWrapper.info("Train Manager","Train user profile table is created.");

			m_DataSet.createTbTrainThreshold();
			
			/**
			 * Summarise LHS2RHS kisses & Subgroup user count
			 */
			m_DataSet.createTbTrainLHS2RHS();
			m_DataSet.createTbTrainSubgroupUser();
			
			Map<Integer,String> attributeIDName = Attribute.getAttributeIDNamePair();
			Set<Map.Entry<Integer, String>> propertyIdNames = attributeIDName.entrySet();
			Iterator<Map.Entry<Integer, String>> propertyIterator = propertyIdNames.iterator();

			while (propertyIterator.hasNext())
			{
				Map.Entry<Integer, String> anEntry = propertyIterator.next();
				Integer typeID = (Integer)anEntry.getKey();
				String typeName =  anEntry.getValue();
				m_DataSet.generateTrainLHS2RHSInteraction(typeID, typeName);
				LoggerWrapper.info("Train Manager","Create interaction summary for attribute --> "+typeName);
				m_DataSet.generateTrainSubgroupUserCount(typeID, typeName);
				LoggerWrapper.info("Train Manager","Create subgroup user summary for attribute --> "+typeName);
			}

			m_DataSet.createTbTrainLookup();
			m_DataSet.createTbTrainMertic();
			LoggerWrapper.info("Train Manager","'-------------- END TRAIN DATA GENERATION PROCESS -----------------'");
		} catch( Throwable th ){
			th.printStackTrace();
			if( conn != null )
				try{ connPool.closeConnection(conn); } catch( Exception e ){}
		} finally {
			connPool.closeConnection(conn);
		}		
	}
	
	
	/**
	 * @param args
	-task 2 -method 6 -mode 1 -pool 10 -cdate "03/05/11"
	 */
	public static void main(String[] args) {
		Preprocessor m_Preprocessor = new Preprocessor("01/07/11", "31/12/11");
		
		
		try {
			m_Preprocessor.initialize();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
